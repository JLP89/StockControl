﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace acceso
{
    public partial class Movimientos : Form
    {
        public Movimientos()
        {
            InitializeComponent();
           // int nHerramienta;
            //int legajoEmpleado;

            //--Aca lo de impresion--
            string[] groupNames = {
	                            "Group1",
	                            "Group2",
	                            "Group3"
                              };
            Random randomObject = new Random();
            //-- aca termina lo de impresion
        }
        private void Usuarios_Load(object sender, EventArgs e)
        {
            if (txbxNPedido.Text.Length ==0)
            {
                btnDevolucion.Hide();
            }
            txbxNPedido.Hide();
            txbxHerramienta.Hide();       
        }
        private void Cerrar_Click(object sender, EventArgs e)
        {
            // dataGridView.Show();
            Movimientos form = new Movimientos();
            form.Close();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            /*
            AccesoDB l = new AccesoDB();
            DateTime fecha =dateTimePicker1.
            fechahora = l.getFechaActual();
            MessageBox.Show(Convert.ToString(fechahora));
            */
            //dataGridView1.Hide();
        }
        public void comboBox1_TextChanged(object sender, EventArgs e)
        {
            //-------------INGRESO DE HERRAMIENTA A BUSCAR--------------------------------
            //int nHerramienta;
            listBxListaHerramientas.Items.Clear();
            cantTotal.Clear();
            textBox7.Clear();
            //comboBox1.Items.Clear();
            List<string>[] listaE = new List<string>[6];
            AccesoDB busqHerr = new AccesoDB();

            string articulo = Convert.ToString(comboBox1.Text);
            //MessageBox.Show(articulo);
            int number;
            bool canConvert = Int32.TryParse(articulo, out number);

            if (canConvert == true)
            {
                listaE = busqHerr.ConsultarHerramienta(articulo);
                int nn = Convert.ToInt32(listaE[1].Count);
                // listBox1.Items.Add(listaE[2]);
                if (comboBox1.Text == null)
                {
                    return;
                }
                else
                {
                    for (int i = 0; i < nn; i++)
                     {
                    
                        //MessageBox.Show("Agregando");
                        listBxListaHerramientas.Items.Add(Convert.ToString(
                             listaE[3][i] + " / " +
                                listaE[2][i]));
                        int cant = int.Parse(listaE[1][i]);
                        cantTotal.Text = cant.ToString();
                        disponiblesPresta.Value = 1;
                        disponiblesPresta.Maximum = int.Parse(listaE[2][i]);
                        disponiblesPresta.Minimum = 1;
                        textBox7.Text = (listaE[0][i]);
                    }
                }
            }
            else
            {
                listaE = busqHerr.ConsultarHerramienta2(articulo);
                int nn = Convert.ToInt32(listaE[1].Count);
                 if (comboBox1.Text == null)
                    {
                        return;
                    }
                    else
                    {
                for (int i = 0; i < nn; i++)
                {
                   
                        //MessageBox.Show("Agregando");
                        listBxListaHerramientas.Items.Add(Convert.ToString(
                                listaE[3][i] + " / " +
                                listaE[2][i]));
                        int cant = int.Parse(listaE[1][i]);
                        cantTotal.Text = cant.ToString();
                        textBox7.Text = (listaE[0][i]);
                        disponiblesPresta.Value = 1;
                        disponiblesPresta.Maximum = int.Parse(listaE[2][i]);
                        disponiblesPresta.Minimum = 1;
                    }
                }

            }
        }

        //-------------------------Aca termina ----------------------------------------------------

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            btnPrestamo.BackColor = Color.Beige;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("devuelve ?", "devuelve", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                try
                {
                    if (txbxNPedido.Text.Length == 0)
                    {
                        MessageBox.Show("Seleccione El pedido  a devolver");
                    }
                    else
                    {
                        List<string>[] pedido = new List<string>[5];
                        AccesoDB devher = new AccesoDB();
                        int numeropedido = Convert.ToInt32(txbxNPedido.Text);
                        string estadoD = "devuelto";
                        string des = txbxHerramienta.Text;
                        MessageBox.Show("la descripccion de la herramienta a devolver es :" + des);
                        int cantd;
                        //int numeropedido = 21;
                        // string estadoHe = Convert.ToString(comboBox2.SelectedValue);
                        //  int eh = 1;
                        int usulegajo = int.Parse(txbxNuEmpleado.Text);
                        devher.devuelveHerramienta(numeropedido, usulegajo, estadoD);

                        DataTable dt = devher.BuscarCantidad(Convert.ToInt32(txbxNPedido.Text));
                        if (dt.Rows.Count > 0)
                        {
                            DataRow row = dt.Rows[0];
                            cantd = Convert.ToInt32(row["cantidadDisponible"]);
                            MessageBox.Show("La cantidad que habia diponble era :" + cantd);
                            cantd = cantd + 1;
                            txbxNPedido.Text = cantd.ToString();
                            //MessageBox.Show(descripccion);
                            AccesoDB cest = new AccesoDB();
                            cest.devuelveHerramientaCambiaEStado(cantd, des);
                            MessageBox.Show("la cantidad disponible es :" + cantd.ToString());

                        }


                        //devher.cambiestadodevuelve
                        MessageBox.Show(numeropedido.ToString());
                        // devher.devuelveHerramienta(numeroherramienta, eDevuelto, estadoHe, eh);

                        txbxNPedido.Clear();
                        txbxHerramienta.Clear();

                        btnPrestamo.BackColor = Color.Gray;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex + " revise la la correcta seleccion de la devolucion ");
                    
                    txbxNPedido.Clear();
                    txbxHerramienta.Clear();
                   
                    btnPrestamo.BackColor = Color.Gray;
                }
            }

            else if(result == DialogResult.No)
            {
                MessageBox.Show("devolucion cancelada");

            }

            
           
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            if (txbxHerramienta.Text == null)
            {
                btnDevolucion.BackColor = Color.SteelBlue;
            }

        }


        private void button1_Click_1(object sender, EventArgs e)
        {


            if (txbxNuEmpleado.Text.Length == 0)
            {
                MessageBox.Show("Debe ingresar empleado");
                return;

            }
            else
                if (txbxBuscHerramienta.Text.Length == 0)
                {
                    MessageBox.Show("debe ingresar Herramienta");
                    return;
                }
                else
                    if(Convert.ToInt32(txbxNuEmpleado.Text) == 6)
                    {
                        MessageBox.Show("No se puede prestar si el usuario esta dado de baja");
                    }
                    else
                    {
                     {
                       {
                        int pañolero = 2;
                        string format = "yyyy-MM-dd HH:MM:ss";
                        string fecha = dateTimePicker1.Value.ToString(format);
                      
                        string estadohe = "bueno";
                        string estado = "prestado";
                        int usuario = int.Parse(txbxNuEmpleado.Text);
                        int herramientaN = int.Parse(textBox7.Text);
                        string descripccion = "veo";
                        if (txbxNuEmpleado.Text.Length == 0)
                        {
                            MessageBox.Show("Debe ingresar el empleado");
                            return;
                        }//finaliza el if
                        else
                        {
                            if (txbxBuscHerramienta.Text.Length == 0)
                            {
                                MessageBox.Show("Debe  ingresar la herramienta");
                            }
                            else
                                if (disponiblesPresta.Value == 0)
                                {
                                    MessageBox.Show("No exite stock de la Herramienta para prestar");
                                    return;
                                }
                                else
                                {
                                    try
                                    {
                                        AccesoDB obtDesc = new AccesoDB();
                                       // obtDesc.Buscarh
                                             DataTable dt = obtDesc.Buscarh(herramientaN);
                                             if (dt.Rows.Count > 0)
                                             {
                                                 DataRow row = dt.Rows[0];
                                                 descripccion = Convert.ToString(row["descripccion"]);
                                                MessageBox.Show(descripccion);
                                             }
                                            
                                        
                                            // aca va yodo el codigo de prestar herramienta...
                                            AccesoDB ap = new AccesoDB();
                                           
                                            int l = Convert.ToInt32(disponiblesPresta.Maximum);
                                            int lpresta = Convert.ToInt32(disponiblesPresta.Maximum);
                                            int l2 = lpresta - 1;

                                            textBox9.Text = l2.ToString();

                                            MessageBox.Show(" el maximo actual para prestar es :" + l.ToString());
                                           
                                            for (int p = 0; p < lpresta;p++ )
                                            {
                                                ap.GuardarRegistro(fecha, herramientaN, descripccion, estadohe, estado, usuario, pañolero);
                                                ap.EstadoHerrPrestar(l2, herramientaN);
                                               // MessageBox.Show("prestamos");
                                            }
                                            txbxNuEmpleado.Clear();
                                            txbxBuscHerramienta.Clear();
                                            textBox9.Clear();
                                            listBxListaHerramientas.Items.Clear();


                                        
                                    }
                        
                                    catch (MySqlException ex)
                                    {
                                        MessageBox.Show("Ha ocurrido un error...." + ex);
                                    }                                

                                }// finaliza el else..
                        }
                    }
                }
        }
        }

        private void comboBox1_TextUpdate(object sender, EventArgs e)
        {
            /*
            listBox1.Items.Clear();
            comboBox1.Items.Clear();

            List<string>[] listaE = new List<string>[4];
            AccesoDB busqHerr = new AccesoDB();
            string articulo = Convert.ToString(comboBox1.Text);
            // string articulo = "1";
            //string articulo = Convert.ToString(textBox1.Text);
            listaE = busqHerr.ConsultarHerramienta(articulo);

            int nn = Convert.ToInt32(listaE[1].Count);
            for (int i = 0; i < nn; i++)
            {
                //MessageBox.Show("Agregando");
                listBox1.Items.Add(Convert.ToString(
                    //listaE[0][i] + " / " +
                    // listaE[1][i] + " " +
                        listaE[2][i] + " / " +
                        listaE[3][i] + " / " +
                        listaE[4][i]));
            }
         */
        }



        public void textBox4_TextChanged(object sender, EventArgs e)
        {
            txbxApellidoYNombre.Clear();
            //listView1.Clear();
            // aca carga empleado
            if (txbxNuEmpleado.Text == "")
            {
                listView1.Items.Clear();
                txbxNPedido.Clear();
                txbxHerramienta.Clear();
               
                
              //  return;
            }
            else
               
                    
                    
                if ( int.Parse(txbxNuEmpleado.Text) == 6)
                {
                    MessageBox.Show("es de baja");
                }

                else
                {
                    {
                        // int nu = Convert.ToInt32(textBox4.Text);
                        //if (nu >0)

                        int emplLeg = Convert.ToInt32(txbxNuEmpleado.Text);
                        listView1.Items.Clear();
                        List<string>[] listaCarreras = new List<string>[2];
                        AccesoDB sc = new AccesoDB();
                        listaCarreras = sc.consultaEstadoPedidos(emplLeg);

                        int ll = Convert.ToInt32(listaCarreras[1].Count);
                        // MessageBox.Show("la cantidad" + ll);
                        for (int i = 0; i < ll; i++)
                        {
                            ListViewItem lvi = new ListViewItem(listaCarreras[0][i]);
                            // MessageBox.Show(listaCarreras[0][1]);
                            lvi.SubItems.Add(listaCarreras[3][i]);
                            lvi.SubItems.Add(listaCarreras[5][i]);



                            listView1.Items.Add(lvi);
                        }

                        // txbxApellidoYNombre.Clear();
                        // string tool = Convert.ToString(comboBox4.Text);

                        int number = 0;
                        bool canConvert = Int32.TryParse(txbxNuEmpleado.Text, out number);
                        if (canConvert == true)
                        {
                            txbxApellidoYNombre.Clear();
                            try
                            {
                                int valor = int.Parse(txbxNuEmpleado.Text);
                                txbxApellidoYNombre.Clear();
                                List<string>[] empleados = new List<string>[5];
                                AccesoDB buscaestado = new AccesoDB();
                                empleados = buscaestado.buscarEmpleado(valor.ToString());
                                int cantEmp = Convert.ToInt32(empleados[1].Count);

                                for (int i = 0; i < cantEmp; i++)
                                {
                                    if (txbxNuEmpleado.Text == null)
                                    {
                                        return;
                                    }
                                    else
                                    {
                                        if (txbxNuEmpleado.Text == empleados[0][i])
                                        {

                                            txbxApellidoYNombre.Text = empleados[1][i] + " " + empleados[2][i];
                                            emplLeg = int.Parse(empleados[0][i]);
                                            txbxNuEmpleado.Text = emplLeg.ToString();
                                        }
                                    }
                                }

                            }

                            catch (Exception ex)
                            {
                                MessageBox.Show(ex + " ha ocurrido alguna clase de error ");
                            }


                        }
                    }


                }
        }
        private void comboBox1_MouseClick(object sender, MouseEventArgs e)
        {
            
            //textBox6.Clear();
            //listBox1.ClearSelected();

        }
        private void listBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
          //  MessageBox.Show(((ListBox)sender).SelectedItem.ToString());
           /* comboBox1.Text= 
            //.SelectedIndex.ToString();
            string valor = listBox1.SelectedIndex.ToString();
            comboBox1.Items.Clear();
            comboBox1.Text =
                .SelectedItem.ToString();
               // listbox1.SelectedItem.ToString();
           * */
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            string curItem = listBxListaHerramientas.SelectedItem.ToString();

            txbxBuscHerramienta.Text = curItem;
           
           // comboBox1.Text = textBox1.Text;
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            if (txbxBuscHerramienta.Text == "")
            {
                listBxListaHerramientas.Items.Clear();
                cantTotal.Clear();
                textBox7.Clear();
                cantTotal.Hide();
                disponiblesPresta.Hide();
                btnPrestamo.BackColor = Color.Gray;
            }
            else
            {
                //comboBox1.Items.Clear();
                List<string>[] listaE = new List<string>[6];
                AccesoDB busqHerr = new AccesoDB();

                string articulo = Convert.ToString(txbxBuscHerramienta.Text);
                //MessageBox.Show(articulo);
                int number;
                string de;

                bool canConvert = Int32.TryParse(articulo, out number);

                if (canConvert == true)
                {
                    listaE = busqHerr.ConsultarHerramienta(articulo);
                    de = listaE[3].ToString();


                    int nn = Convert.ToInt32(listaE[1].Count);
                    // listBox1.Items.Add(listaE[2]);
                    if (txbxBuscHerramienta.Text == null)
                    {
                        return;
                    }
                    else
                    {
                        for (int i = 0; i < nn; i++)
                        {
                            //MessageBox.Show("Agregando");
                            listBxListaHerramientas.Items.Add(Convert.ToString( /*listaE[1][i] + " / " +*/ listaE[3][i]));
                            int cant = int.Parse(listaE[1][i]);
                            cantTotal.Text = cant.ToString();
                            de = listaE[3].ToString();
                            // textBox10.Text = de;

                            disponiblesPresta.Maximum = int.Parse(listaE[2][i]);
                            disponiblesPresta.Minimum = int.Parse(listaE[2][i]);
                            //numericUpDown1.Value = 1;
                            if (disponiblesPresta.Value > 0)
                            {
                                disponiblesPresta.Minimum = 1;
                                btnPrestamo.Visible = true;
                                btnPrestamo.BackColor = Color.Green;
                                label7.Show();
                                cantTotal.Show();
                                label5.Show();
                                disponiblesPresta.Show();


                            }
                            else
                                if (disponiblesPresta.Value == 0)
                                {
                                    btnPrestamo.Visible = false;
                                    MessageBox.Show("No hay stock Para prestar");
                                }
                            // numericUpDown1.Minimum = 1; 
                            textBox7.Text = (listaE[0][i]);
                        }
                    }

                }
                else
                {
                    listaE = busqHerr.ConsultarHerramienta2(articulo);
                    int nn = Convert.ToInt32(listaE[1].Count);
                    if (comboBox1.Text == null)
                    {
                        return;
                    }
                    else
                    {
                        for (int i = 0; i < nn; i++)
                        {

                            //MessageBox.Show("Agregando");
                            listBxListaHerramientas.Items.Add(Convert.ToString(listaE[3][i]));
                            /*listBox1.Items.Add(Convert.ToString(
                                    listaE[3][i] + " / " +
                                    listaE[2][i]));
                             * */
                            int cant = int.Parse(listaE[1][i]);
                            cantTotal.Text = cant.ToString();
                            textBox7.Text = (listaE[0][i]);
                            //numericUpDown1.Value = 1;
                            disponiblesPresta.Maximum = int.Parse(listaE[2][i]);
                            disponiblesPresta.Minimum = int.Parse(listaE[2][i]);
                        }
                    }

                }
            }
        }
        private void dateTimePicker1_ValueChanged_1(object sender, EventArgs e)
        {
            DateTime result = dateTimePicker1.Value;
            this.Text = result.ToString();
        }
        private void button3_Click_1(object sender, EventArgs e)
        {
            listBxListaHerramientas.ClearSelected();
        }
        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            ListViewItem item = listView1.GetItemAt( e.X , e.Y);
            string estado = item.SubItems[2].Text;
            if (item != null && estado == "prestado")
            {

                txbxNPedido.Text = item.SubItems[0].Text;
                txbxHerramienta.Text = item.SubItems[1].Text;
                txbxNPedido.Show();
                txbxHerramienta.Show();
                btnDevolucion.Show();
                btnDevolucion.BackColor = Color.Green;

            }
            else
            {
                MessageBox.Show("la herramienta ya esta devuelta");
            }
        }

        private void listView1_MouseClick(object sender, MouseEventArgs e)
        {
            
            txbxNPedido.Clear();
            txbxHerramienta.Clear();
            btnDevolucion.Show();
            btnDevolucion.BackColor = Color.Gray;
            txbxNPedido.Hide();          
            txbxHerramienta.Hide();
        }
    }
}