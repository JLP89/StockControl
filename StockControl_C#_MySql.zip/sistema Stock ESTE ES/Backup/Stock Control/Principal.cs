﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace WindowsFormsApplication1
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            State newMDIChild = new State();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {

        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void consultaDeStockToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void personalToolStripMenuItem_Click(object sender, EventArgs e)
        {
           


        }

        private void sistemaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void deToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ayudaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
             Movements newMDIChild = new Movements();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();

            
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            {
                foreach (var form in Application.OpenForms.Cast<Form>().Where(f => f.IsMdiChild).ToArray()) // ToArray necessary to build a snapshot
                    form.Close();
                // Abrir Formulario Estado

                State newMDIChild = new State();
                newMDIChild.MdiParent = this;
                newMDIChild.Show(); 
            }










        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            State newMDIChild = new State();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();
        }

        private void ayudaToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void acercaDeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            about form1 = new about();

            form1.Show();
           
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            State newMDIChild = new State();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Desea Salir? ");
            
            Application.Exit();
        }
    }
}
