﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace acceso
{
    public partial class Mantenimiento : Form
    {
        public Mantenimiento()
        {
            InitializeComponent();

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            AccesoDB abd = new AccesoDB();
            bool verAcceso = false;

            List<string> lista = new List<string>();
            try
            {
                lista = abd.Verificación(ref verAcceso, textBox6.Text, textBox7.Text, textBox8.Text, textBox9.Text);
                verAcceso = true;
            }

            catch
            {
                verAcceso = false;
            }
            if (verAcceso == true)
            {
                listBox2.Items.Add("              CONEXIÓN EXITOSA");
                listBox2.Items.Add("");

                for (int i = 0; i < lista.Count; i++)
                { listBox2.Items.Add(lista[i]); }




            }

            else
            {
                listBox2.Items.Add("              CONEXIÓN NO EXITOSA");
                listBox2.Items.Add("              Llame a Mesa de Ayuda");
                MessageBox.Show(lista[0]);
            }




        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
           
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*AccesoDB bUP = new AccesoDB();
            bUP.DataBaseBackup("C:/wamp64/bin/mysql/mysql5.7.9/bin.mysqldump.exe", "controlstock");
            //bUP.DataBaseBackup("C:/Program Files/MySQL/MySQL Server 5.6/bin.mysqldump.exe", "stockcontrol");
        **/
            AccesoDB imp = new AccesoDB();
            try
            {
                string db = textBox9.Text;
                string AImp = textBox5.Text;
                imp.importar(AImp);
            }
            catch (Exception ex)
            {
                if (textBox5.Text.Length == 0)
                {
                    MessageBox.Show("Seleccione el archivo sql a importar:  ");
                }
                else
                    MessageBox.Show("Consulte a mesa de ayuda " + ex);
            }






        }


        private void button3_Click(object sender, EventArgs e)
        {


            try
            {

                if (textBox15.Text.Length == 0)
                {
                    MessageBox.Show("desea guardar por defecto en D:\\ ?");
                    // textBox15.Text = rExp;
                    //exp.Exportar(rExp);
                    AccesoDB exp = new AccesoDB();
                    string rExp;
                    rExp = "D:\\";
                    exp.Exportar(rExp);
                }
                else
                {
                    AccesoDB exp = new AccesoDB();
                    // string rExp;
                    string rExp = textBox15.Text;
                    exp.Exportar(rExp);
                    textBox15.Clear();
                }
                MessageBox.Show("Se Ha Exportado exitosamente!");
            }
            catch
            {
                MessageBox.Show("ha ocurrido un error  consulte a mesa de ayuda... ");
            }


        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            // openFileDialog1 open = new openFileDialog1();



        }

        private void abrirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Archivos .sql (*.sql)|*.sql";
            open.Title = "Archivos txt";
            if (open.ShowDialog() == DialogResult.OK)
            {
                textBox5.Text = open.FileName;
            }

            open.Dispose();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Archivos .sql (*.sql)|*.sql";
            open.Title = "Archivos txt";
            if (open.ShowDialog() == DialogResult.OK)
            {
                textBox5.Text = open.FileName;
            }

            open.Dispose();
        }

        public void button7_Click(object sender, EventArgs e)
        {
            button3.Show();
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            fbd.RootFolder = Environment.SpecialFolder.MyComputer;
            fbd.Description = "Seleccione ruta donde guardara el backUp";
            if (fbd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                MessageBox.Show("fbd.SelectedPath");

                string path = fbd.SelectedPath;
                textBox15.Text = path;
                MessageBox.Show(path);
            }
        }

        private void Mantenimiento_Load(object sender, EventArgs e)
        {
            

        }

        private void button7_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox5_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Archivos .sql (*.sql)|*.sql";
            open.Title = "Archivos txt";
            if (open.ShowDialog() == DialogResult.OK)
            {
                textBox5.Text = open.FileName;
            }

            open.Dispose();
        }

        private void textBox15_DoubleClick(object sender, EventArgs e)
        {
            button3.Show();
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            fbd.RootFolder = Environment.SpecialFolder.MyComputer;
            fbd.Description = "Seleccione ruta donde guardara el backUp";
            if (fbd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                // MessageBox.Show("fbd.SelectedPath");

                string path = fbd.SelectedPath;
                textBox15.Text = path;
                // MessageBox.Show(path);
            }
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click_1(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void tabPagPersonal_Click(object sender, EventArgs e)
        {

        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void button9_DragOver(object sender, DragEventArgs e)
        {

        }

        private void textBox19_TextChanged(object sender, EventArgs e)
        {
            listBEmpleados.Items.Clear();
            textBNombre.Clear();
            textBLegajo.Clear();
            textBApellido.Clear();
            textBNivel.Clear();         
            textBContraseña.Clear();

            if (textBxEmpleado.Text == "")
            {
                listBEmpleados.Items.Clear();
                textBNombre.Clear();
                textBLegajo.Clear();
                textBApellido.Clear();
                comboBNivel.Items.Clear();
                textBContraseña.Clear();

            }

            else
            {


                List<string>[] lista = new List<string>[5];
                AccesoDB busqEmpl = new AccesoDB();
                string empleado = textBxEmpleado.Text;

                //int IdE = Convert.ToInt32(textBxEmpleado.Text);
                int leg;
                bool convierte = Int32.TryParse(empleado, out leg);

                if (convierte == true)
                {
                    lista = busqEmpl.buscarEmpleado(empleado);
                    int ne = lista[0].Count();

                    for (int i = 0; i < ne; i++)
                    {
                        listBEmpleados.Items.Add(Convert.ToString(lista[1][i] + "  " + lista[2][i].ToString()));
                        textBLegajo.Text = lista[0][i].ToString();
                        textBNombre.Text = lista[1][i].ToString();
                        textBApellido.Text = lista[2][i].ToString();
                        textBNivel.Text = lista[3][i].ToString();
                        textBContraseña.Text = lista[4][i].ToString();
                    }

                }


                /* busqE.buscarEmpleado(Convert.ToString());
                  //textBLegajo.Text = Convert.ToString(busqE[2][i]);
                    
                      lista[0].ToString();
               
                  */

            }
        }

        private void listBEmpleados_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            MessageBox.Show("aca agregaremos");
            string nombre = textBNombre.Text;
            string apellido = textBApellido.Text;
            int nivel = Convert.ToInt32(textBNivel.Text);

            int contraseña = int.Parse(textBContraseña.Text);
            MessageBox.Show(contraseña.ToString());
            AccesoDB altaUsuario = new AccesoDB();
            List<string>[] busLega = new List<string>[4];
            busLega = altaUsuario.ConsultarLegajo();
            int nl = Convert.ToInt32(busLega[0].Count());
            nl++;
            textBLegajo.Text = nl.ToString();

            if (nombre.Length == 0)
            {
                MessageBox.Show("Ingrese el Nombre ");

            }
            else
                if (apellido.Length == 0)
                {
                    MessageBox.Show("Ingrese el Apellido");
                }
                else
                    if (textBNivel == null)
                    {
                        MessageBox.Show("Ingrese el Nivel");
                    }
                    else
                        if (textBContraseña.Text.Length == 0)
                        {
                            MessageBox.Show("Ingrese la contraseña ");
                        }
                        else

                            try
                            {
                                altaUsuario.altaUsuarios(nl, nombre, apellido, nivel, contraseña);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(" revise el correcto ingreso de los datos" + ex);
                            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            int legajo = Convert.ToInt32(textBLegajo.Text);
            AccesoDB baja = new AccesoDB();
            int empleado = int.Parse(textBLegajo.Text);
            string estado = "devuelto";
            baja.modificIdUsuarioBajaPedidos(empleado);
            int idBajaE = 6;
            baja.devuelveTBajaE(idBajaE, estado); //hacemos que devuelva todo lo prestado
            baja.eliminarUsuario(empleado); // eliminamos el usuario.

            listBEmpleados.Items.Clear();
            textBNombre.Clear();
            textBLegajo.Clear();
            textBApellido.Clear();
            textBNivel.Clear();
            textBContraseña.Clear();



        }

        private void button14_Click(object sender, EventArgs e)
        {
            
            int hCantidad = Convert.ToInt32(textBCant.Text);
            int hCantDisptextBDisp = hCantidad;   
             textBDisp.Text = hCantDisptextBDisp.ToString();        
            string descripcion = textBDesc.Text;
            AccesoDB addH = new AccesoDB();
            List<string>[] busLegah = new List<string>[0];
            busLegah = addH.ConsultarLegajoH();
            int nl = Convert.ToInt32(busLegah[0].Count());
            nl = nl + 1;         
            textBID.Text = nl.ToString();
            string estadoherr = "bueno";
            int estado = 1;
            try
            {
                addH.altaHerramientas(nl, hCantidad, hCantDisptextBDisp, descripcion, estadoherr, estado);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ha ocurrido un error  consulte a mesa de ayuda" + ex);
            }


            
        }

        private void textBHerramientas_TextChanged(object sender, EventArgs e)
        {
            listBoxHerramientas.Items.Clear();//limpio la lista
           // buttonHAdd.Hide();
           // buttonHAdd.Show();
            textBID.Clear();
            textBCant.Clear();
            textBDesc.Clear();
            textBDisp.Clear();

            if (textBHerramientas.Text == "")
            {

                listBoxHerramientas.Items.Clear();//limpio la lista
                //buttonHAdd.Hide();
                textBID.Clear();
                textBCant.Clear();
                textBDesc.Clear();
            }

            else
            {

                List<string>[] listaH = new List<string>[5];
                AccesoDB busqHerram = new AccesoDB();
                string herramienta = textBHerramientas.Text;
                int idHerr;
                bool convierte = Int32.TryParse(herramienta, out idHerr);

                if (convierte == true)
                {
                    listaH = busqHerram.buscHerraID(herramienta);

                    int ne = listaH[0].Count();
                    if (textBxEmpleado.Text == null)
                    {
                        return;
                    }

                    else
                    {
                        for (int i = 0; i < ne; i++)
                        {
                            listBoxHerramientas.Items.Add(Convert.ToString(listaH[3][i].ToString()));
                            textBID.Text = listaH[0][i].ToString();
                            textBCant.Text = listaH[1][i].ToString();
                            textBDisp.Text = listaH[2][i].ToString();
                            textBDesc.Text = listaH[3][i].ToString();
                        }
                    }
                }
                else
                {
                    listaH = busqHerram.ConsultarHerramienta2(herramienta);

                    int nn = Convert.ToInt32(listaH[0].Count);
                    if (textBHerramientas.Text == null)
                     {
                      return;
                     }
                    else
                    {
                     for (int i = 0; i < nn; i++)
                     {
                      listBoxHerramientas.Items.Add(Convert.ToString(listaH[3][i]));

                      textBID.Text = listaH[0][i].ToString();
                      textBCant.Text = listaH[1][i].ToString();
                      textBDisp.Text = listaH[2][i].ToString();
                      textBDesc.Text = listaH[3][i].ToString();                          
                        }
                    }





                }














            }
        }

        private void listBoxHerramientas_DoubleClick(object sender, EventArgs e)
        {
            string h = listBoxHerramientas.SelectedItem.ToString();
            textBHerramientas.Text = h;                     
           
        }

        private void buttonHDel_Click(object sender, EventArgs e)
        {
            AccesoDB bajaH = new AccesoDB();
            int idHe = Convert.ToInt32(textBID.Text);
            string estado = "devuelto";
            bajaH.modificIdHerramientaBajaPedidos(idHe);

            bajaH.devuelveTBajaH(idHe, estado);
            bajaH.eliminarHerramienta(idHe);

            /*
            
           
            baja.modificIdUsuarioBajaPedidos(empleado);
            int idBajaE = 6;
            baja.devuelveTBajaE(idBajaE, estado);
            baja.eliminarUsuario(empleado);
            */

        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void buttonHMod_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {

        }
    }
}