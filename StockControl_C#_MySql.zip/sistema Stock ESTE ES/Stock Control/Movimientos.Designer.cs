﻿namespace acceso
{
    partial class Movimientos
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Movimientos));
            this.listView1 = new System.Windows.Forms.ListView();
            this.pedidoID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.descripccion = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.estado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label4 = new System.Windows.Forms.Label();
            this.txbxNuEmpleado = new System.Windows.Forms.TextBox();
            this.txbxApellidoYNombre = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnPrestamo = new System.Windows.Forms.Button();
            this.btnDevolucion = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.disponiblesPresta = new System.Windows.Forms.NumericUpDown();
            this.listBxListaHerramientas = new System.Windows.Forms.ListBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cantTotal = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.txbxBuscHerramienta = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.agregar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.quitar = new System.Windows.Forms.Button();
            this.Cerrar = new System.Windows.Forms.Button();
            this.legajo = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.directoryEntry1 = new System.DirectoryServices.DirectoryEntry();
            this.txbxHerramienta = new System.Windows.Forms.TextBox();
            this.txbxNPedido = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.disponiblesPresta)).BeginInit();
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.pedidoID,
            this.descripccion,
            this.estado});
            this.listView1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.listView1.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView1.GridLines = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(0, 300);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(1284, 260);
            this.listView1.TabIndex = 19;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            this.listView1.Click += new System.EventHandler(this.listView1_Click);
            this.listView1.DoubleClick += new System.EventHandler(this.listView1_DoubleClick);
            this.listView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseClick);
            this.listView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseDoubleClick);
            // 
            // pedidoID
            // 
            this.pedidoID.Text = "Pedido";
            // 
            // descripccion
            // 
            this.descripccion.Text = "Herramienta";
            this.descripccion.Width = 202;
            // 
            // estado
            // 
            this.estado.Text = "Estado";
            this.estado.Width = 96;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(313, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 22;
            this.label4.Text = "Herramienta : ";
            // 
            // txbxNuEmpleado
            // 
            this.txbxNuEmpleado.Location = new System.Drawing.Point(15, 25);
            this.txbxNuEmpleado.Name = "txbxNuEmpleado";
            this.txbxNuEmpleado.Size = new System.Drawing.Size(95, 20);
            this.txbxNuEmpleado.TabIndex = 26;
            this.txbxNuEmpleado.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textBox4_MouseClick);
            this.txbxNuEmpleado.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // txbxApellidoYNombre
            // 
            this.txbxApellidoYNombre.Location = new System.Drawing.Point(15, 68);
            this.txbxApellidoYNombre.Name = "txbxApellidoYNombre";
            this.txbxApellidoYNombre.Size = new System.Drawing.Size(233, 20);
            this.txbxApellidoYNombre.TabIndex = 28;
            this.txbxApellidoYNombre.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(313, 181);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 13);
            this.label7.TabIndex = 29;
            this.label7.Text = "Cantidad  Total : ";
            this.label7.Visible = false;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // btnPrestamo
            // 
            this.btnPrestamo.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnPrestamo.Location = new System.Drawing.Point(522, 180);
            this.btnPrestamo.Name = "btnPrestamo";
            this.btnPrestamo.Size = new System.Drawing.Size(136, 46);
            this.btnPrestamo.TabIndex = 31;
            this.btnPrestamo.Text = "PRESTAMO";
            this.btnPrestamo.UseVisualStyleBackColor = false;
            this.btnPrestamo.Click += new System.EventHandler(this.button1_Click_1);
            this.btnPrestamo.MouseLeave += new System.EventHandler(this.button1_MouseLeave);
            this.btnPrestamo.MouseHover += new System.EventHandler(this.button1_MouseHover);
            // 
            // btnDevolucion
            // 
            this.btnDevolucion.BackColor = System.Drawing.Color.SlateGray;
            this.btnDevolucion.Location = new System.Drawing.Point(522, 234);
            this.btnDevolucion.Name = "btnDevolucion";
            this.btnDevolucion.Size = new System.Drawing.Size(136, 46);
            this.btnDevolucion.TabIndex = 32;
            this.btnDevolucion.Text = "DEVOLUCION";
            this.btnDevolucion.UseVisualStyleBackColor = false;
            this.btnDevolucion.Click += new System.EventHandler(this.button2_Click);
            this.btnDevolucion.MouseEnter += new System.EventHandler(this.button2_MouseEnter);
            this.btnDevolucion.MouseLeave += new System.EventHandler(this.button2_MouseLeave);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 95);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 13);
            this.label8.TabIndex = 33;
            this.label8.Text = "Fecha : ";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(15, 111);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(233, 20);
            this.dateTimePicker1.TabIndex = 34;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged_1);
            // 
            // disponiblesPresta
            // 
            this.disponiblesPresta.Location = new System.Drawing.Point(424, 209);
            this.disponiblesPresta.Name = "disponiblesPresta";
            this.disponiblesPresta.Size = new System.Drawing.Size(42, 20);
            this.disponiblesPresta.TabIndex = 35;
            this.disponiblesPresta.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // listBxListaHerramientas
            // 
            this.listBxListaHerramientas.FormattingEnabled = true;
            this.listBxListaHerramientas.Location = new System.Drawing.Point(316, 61);
            this.listBxListaHerramientas.Name = "listBxListaHerramientas";
            this.listBxListaHerramientas.Size = new System.Drawing.Size(342, 108);
            this.listBxListaHerramientas.TabIndex = 37;
            this.listBxListaHerramientas.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            this.listBxListaHerramientas.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listBox1_MouseDoubleClick);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 13);
            this.label9.TabIndex = 38;
            this.label9.Text = "N° Empleado : ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 52);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 13);
            this.label10.TabIndex = 39;
            this.label10.Text = "Apellido y Nombre :";
            // 
            // cantTotal
            // 
            this.cantTotal.Location = new System.Drawing.Point(397, 178);
            this.cantTotal.Name = "cantTotal";
            this.cantTotal.ReadOnly = true;
            this.cantTotal.Size = new System.Drawing.Size(42, 20);
            this.cantTotal.TabIndex = 30;
            this.cantTotal.Visible = false;
            this.cantTotal.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(313, 211);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 13);
            this.label5.TabIndex = 40;
            this.label5.Text = "Disponibles /Presta :";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(625, 25);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(33, 20);
            this.textBox7.TabIndex = 41;
            this.textBox7.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // txbxBuscHerramienta
            // 
            this.txbxBuscHerramienta.Location = new System.Drawing.Point(316, 25);
            this.txbxBuscHerramienta.Name = "txbxBuscHerramienta";
            this.txbxBuscHerramienta.Size = new System.Drawing.Size(294, 20);
            this.txbxBuscHerramienta.TabIndex = 43;
            this.txbxBuscHerramienta.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(472, 209);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(25, 20);
            this.textBox9.TabIndex = 44;
            this.textBox9.Visible = false;
            // 
            // agregar
            // 
            this.agregar.Location = new System.Drawing.Point(1022, 68);
            this.agregar.Name = "agregar";
            this.agregar.Size = new System.Drawing.Size(74, 23);
            this.agregar.TabIndex = 2;
            this.agregar.Text = "Agregar";
            this.agregar.UseVisualStyleBackColor = true;
            this.agregar.Visible = false;
            this.agregar.Click += new System.EventHandler(this.agregar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(858, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nro";
            this.label2.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.textBox1.Location = new System.Drawing.Point(908, 70);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(95, 20);
            this.textBox1.TabIndex = 4;
            this.textBox1.Visible = false;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(858, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Sector";
            this.label3.Visible = false;
            // 
            // quitar
            // 
            this.quitar.Location = new System.Drawing.Point(1021, 102);
            this.quitar.Name = "quitar";
            this.quitar.Size = new System.Drawing.Size(75, 23);
            this.quitar.TabIndex = 6;
            this.quitar.Text = "Devuelve";
            this.quitar.UseVisualStyleBackColor = true;
            this.quitar.Visible = false;
            this.quitar.Click += new System.EventHandler(this.quitar_Click);
            // 
            // Cerrar
            // 
            this.Cerrar.Location = new System.Drawing.Point(1022, 135);
            this.Cerrar.Name = "Cerrar";
            this.Cerrar.Size = new System.Drawing.Size(75, 23);
            this.Cerrar.TabIndex = 8;
            this.Cerrar.Text = "Cerrar";
            this.Cerrar.UseVisualStyleBackColor = true;
            this.Cerrar.Visible = false;
            this.Cerrar.Click += new System.EventHandler(this.Cerrar_Click);
            // 
            // legajo
            // 
            this.legajo.AutoSize = true;
            this.legajo.Location = new System.Drawing.Point(858, 107);
            this.legajo.Name = "legajo";
            this.legajo.Size = new System.Drawing.Size(41, 13);
            this.legajo.TabIndex = 9;
            this.legajo.Text = "legajo :";
            this.legajo.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.textBox2.Location = new System.Drawing.Point(908, 104);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(97, 20);
            this.textBox2.TabIndex = 10;
            this.textBox2.Visible = false;
            // 
            // textBox3
            // 
            this.textBox3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.textBox3.Location = new System.Drawing.Point(906, 137);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(99, 20);
            this.textBox3.TabIndex = 11;
            this.textBox3.Visible = false;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(975, 178);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 42;
            this.comboBox2.Visible = false;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(814, 273);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(233, 21);
            this.comboBox1.TabIndex = 23;
            this.comboBox1.TabStop = false;
            this.comboBox1.Visible = false;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged_1);
            this.comboBox1.TextUpdate += new System.EventHandler(this.comboBox1_TextUpdate);
            this.comboBox1.TextChanged += new System.EventHandler(this.comboBox1_TextChanged);
            this.comboBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.comboBox1_MouseClick);
            // 
            // txbxHerramienta
            // 
            this.txbxHerramienta.Location = new System.Drawing.Point(329, 248);
            this.txbxHerramienta.Name = "txbxHerramienta";
            this.txbxHerramienta.ReadOnly = true;
            this.txbxHerramienta.Size = new System.Drawing.Size(187, 20);
            this.txbxHerramienta.TabIndex = 48;
            // 
            // txbxNPedido
            // 
            this.txbxNPedido.Location = new System.Drawing.Point(223, 248);
            this.txbxNPedido.Name = "txbxNPedido";
            this.txbxNPedido.ReadOnly = true;
            this.txbxNPedido.Size = new System.Drawing.Size(100, 20);
            this.txbxNPedido.TabIndex = 52;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(110, 171);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(138, 23);
            this.button2.TabIndex = 53;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // Movimientos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(1284, 560);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.txbxNPedido);
            this.Controls.Add(this.txbxHerramienta);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.txbxBuscHerramienta);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.listBxListaHerramientas);
            this.Controls.Add(this.disponiblesPresta);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnDevolucion);
            this.Controls.Add(this.btnPrestamo);
            this.Controls.Add(this.cantTotal);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txbxApellidoYNombre);
            this.Controls.Add(this.txbxNuEmpleado);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.legajo);
            this.Controls.Add(this.Cerrar);
            this.Controls.Add(this.quitar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.agregar);
            this.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Movimientos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = " ";
            this.Load += new System.EventHandler(this.Usuarios_Load);
            ((System.ComponentModel.ISupportInitialize)(this.disponiblesPresta)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader descripccion;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txbxNuEmpleado;
        private System.Windows.Forms.TextBox txbxApellidoYNombre;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnPrestamo;
        private System.Windows.Forms.Button btnDevolucion;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.NumericUpDown disponiblesPresta;
        private System.Windows.Forms.ListBox listBxListaHerramientas;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox cantTotal;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox txbxBuscHerramienta;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Button agregar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button quitar;
        private System.Windows.Forms.Button Cerrar;
        private System.Windows.Forms.Label legajo;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.DirectoryServices.DirectoryEntry directoryEntry1;
        private System.Windows.Forms.ColumnHeader estado;
        private System.Windows.Forms.ColumnHeader pedidoID;
        private System.Windows.Forms.TextBox txbxHerramienta;
        private System.Windows.Forms.TextBox txbxNPedido;
        private System.Windows.Forms.Button button2;
    }
}