﻿namespace acceso
{
    partial class Mantenimiento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Mantenimiento));
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPagPersonal = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label29 = new System.Windows.Forms.Label();
            this.textBNivel = new System.Windows.Forms.TextBox();
            this.comboBNivel = new System.Windows.Forms.ComboBox();
            this.textBContraseña = new System.Windows.Forms.TextBox();
            this.textBApellido = new System.Windows.Forms.TextBox();
            this.textBNombre = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.textBLegajo = new System.Windows.Forms.TextBox();
            this.textBxEmpleado = new System.Windows.Forms.TextBox();
            this.listBEmpleados = new System.Windows.Forms.ListBox();
            this.buttonBaja = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textBDesc = new System.Windows.Forms.TextBox();
            this.textBDisp = new System.Windows.Forms.TextBox();
            this.textBCant = new System.Windows.Forms.TextBox();
            this.textBID = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBHerramientas = new System.Windows.Forms.TextBox();
            this.listBoxHerramientas = new System.Windows.Forms.ListBox();
            this.buttonHDel = new System.Windows.Forms.Button();
            this.buttonHMod = new System.Windows.Forms.Button();
            this.buttonHAdd = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button8 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPagPersonal.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.ForeColor = System.Drawing.Color.SteelBlue;
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(755, 493);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Conexión/BackUp";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.SteelBlue;
            this.groupBox2.Controls.Add(this.button6);
            this.groupBox2.Controls.Add(this.textBox15);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.textBox5);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.textBox9);
            this.groupBox2.Controls.Add(this.textBox8);
            this.groupBox2.Controls.Add(this.textBox7);
            this.groupBox2.Controls.Add(this.textBox6);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.listBox2);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox2.Location = new System.Drawing.Point(1, 10);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(756, 481);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(128, 19);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(244, 27);
            this.button6.TabIndex = 38;
            this.button6.Text = "Prueba de conexión";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(39, 413);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(410, 20);
            this.textBox15.TabIndex = 37;
            this.textBox15.TextChanged += new System.EventHandler(this.textBox15_TextChanged);
            this.textBox15.DoubleClick += new System.EventHandler(this.textBox15_DoubleClick);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(36, 388);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 13);
            this.label10.TabIndex = 36;
            this.label10.Text = "Guardar en :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(36, 311);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 13);
            this.label9.TabIndex = 34;
            this.label9.Text = "Ruta : ";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(39, 338);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(410, 20);
            this.textBox5.TabIndex = 33;
            this.textBox5.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.textBox5_MouseDoubleClick);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(473, 400);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(135, 45);
            this.button3.TabIndex = 31;
            this.button3.Text = "Exportar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(473, 324);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(135, 47);
            this.button1.TabIndex = 30;
            this.button1.Text = "Importar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(473, 243);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(135, 20);
            this.textBox9.TabIndex = 29;
            this.textBox9.Text = "controlstock";
            this.textBox9.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(473, 179);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(135, 20);
            this.textBox8.TabIndex = 28;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(473, 122);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(135, 20);
            this.textBox7.TabIndex = 27;
            this.textBox7.Text = "root";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(473, 74);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(135, 20);
            this.textBox6.TabIndex = 26;
            this.textBox6.Text = "localhost";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(500, 227);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "BASE DE DATOS";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(500, 163);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 13);
            this.label7.TabIndex = 24;
            this.label7.Text = "PASSWORD";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(500, 106);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "USUARIO";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(500, 49);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 13);
            this.label5.TabIndex = 22;
            this.label5.Text = "SERVIDOR";
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(36, 65);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(413, 212);
            this.listBox2.TabIndex = 21;
            this.listBox2.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(112, 220);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(244, 27);
            this.button2.TabIndex = 20;
            this.button2.Text = "Prueba de conexión";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPagPersonal);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(16, 15);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(763, 519);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.Tag = "";
            // 
            // tabPagPersonal
            // 
            this.tabPagPersonal.BackColor = System.Drawing.Color.SteelBlue;
            this.tabPagPersonal.Controls.Add(this.groupBox5);
            this.tabPagPersonal.Location = new System.Drawing.Point(4, 22);
            this.tabPagPersonal.Name = "tabPagPersonal";
            this.tabPagPersonal.Size = new System.Drawing.Size(755, 493);
            this.tabPagPersonal.TabIndex = 4;
            this.tabPagPersonal.Text = "Personal";
            this.tabPagPersonal.Click += new System.EventHandler(this.tabPagPersonal_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label29);
            this.groupBox5.Controls.Add(this.textBNivel);
            this.groupBox5.Controls.Add(this.comboBNivel);
            this.groupBox5.Controls.Add(this.textBContraseña);
            this.groupBox5.Controls.Add(this.textBApellido);
            this.groupBox5.Controls.Add(this.textBNombre);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.label22);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.textBLegajo);
            this.groupBox5.Controls.Add(this.textBxEmpleado);
            this.groupBox5.Controls.Add(this.listBEmpleados);
            this.groupBox5.Controls.Add(this.buttonBaja);
            this.groupBox5.Controls.Add(this.button11);
            this.groupBox5.Controls.Add(this.button9);
            this.groupBox5.Location = new System.Drawing.Point(23, 12);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(561, 237);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Enter += new System.EventHandler(this.groupBox5_Enter);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(32, 17);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(126, 13);
            this.label29.TabIndex = 19;
            this.label29.Text = "Busqueda de Empleado ;";
            // 
            // textBNivel
            // 
            this.textBNivel.Location = new System.Drawing.Point(290, 113);
            this.textBNivel.Name = "textBNivel";
            this.textBNivel.Size = new System.Drawing.Size(42, 20);
            this.textBNivel.TabIndex = 18;
            // 
            // comboBNivel
            // 
            this.comboBNivel.AutoCompleteCustomSource.AddRange(new string[] {
            "Administrador",
            "Pañolero",
            "Supervisor",
            "Gerente",
            "Empleado"});
            this.comboBNivel.FormattingEnabled = true;
            this.comboBNivel.Location = new System.Drawing.Point(354, 113);
            this.comboBNivel.Name = "comboBNivel";
            this.comboBNivel.Size = new System.Drawing.Size(54, 21);
            this.comboBNivel.TabIndex = 17;
            // 
            // textBContraseña
            // 
            this.textBContraseña.Location = new System.Drawing.Point(290, 145);
            this.textBContraseña.Name = "textBContraseña";
            this.textBContraseña.Size = new System.Drawing.Size(158, 20);
            this.textBContraseña.TabIndex = 16;
            // 
            // textBApellido
            // 
            this.textBApellido.Location = new System.Drawing.Point(290, 77);
            this.textBApellido.Name = "textBApellido";
            this.textBApellido.Size = new System.Drawing.Size(158, 20);
            this.textBApellido.TabIndex = 14;
            // 
            // textBNombre
            // 
            this.textBNombre.Location = new System.Drawing.Point(290, 37);
            this.textBNombre.Name = "textBNombre";
            this.textBNombre.Size = new System.Drawing.Size(158, 20);
            this.textBNombre.TabIndex = 13;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(209, 148);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(70, 13);
            this.label25.TabIndex = 12;
            this.label25.Text = "Contraseña : ";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(239, 113);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(40, 13);
            this.label24.TabIndex = 11;
            this.label24.Text = "Nivel : ";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(226, 77);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 13);
            this.label23.TabIndex = 10;
            this.label23.Text = "Apellido : ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(226, 40);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(53, 13);
            this.label22.TabIndex = 9;
            this.label22.Text = "Nombre : ";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(226, 183);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(48, 13);
            this.label21.TabIndex = 8;
            this.label21.Text = "Legajo : ";
            // 
            // textBLegajo
            // 
            this.textBLegajo.Location = new System.Drawing.Point(290, 180);
            this.textBLegajo.Name = "textBLegajo";
            this.textBLegajo.Size = new System.Drawing.Size(66, 20);
            this.textBLegajo.TabIndex = 7;
            // 
            // textBxEmpleado
            // 
            this.textBxEmpleado.Location = new System.Drawing.Point(22, 37);
            this.textBxEmpleado.Name = "textBxEmpleado";
            this.textBxEmpleado.Size = new System.Drawing.Size(184, 20);
            this.textBxEmpleado.TabIndex = 6;
            this.textBxEmpleado.TextChanged += new System.EventHandler(this.textBox19_TextChanged);
            // 
            // listBEmpleados
            // 
            this.listBEmpleados.FormattingEnabled = true;
            this.listBEmpleados.Location = new System.Drawing.Point(22, 63);
            this.listBEmpleados.Name = "listBEmpleados";
            this.listBEmpleados.Size = new System.Drawing.Size(184, 147);
            this.listBEmpleados.TabIndex = 5;
            this.listBEmpleados.SelectedIndexChanged += new System.EventHandler(this.listBEmpleados_SelectedIndexChanged);
            // 
            // buttonBaja
            // 
            this.buttonBaja.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBaja.Location = new System.Drawing.Point(491, 98);
            this.buttonBaja.Name = "buttonBaja";
            this.buttonBaja.Size = new System.Drawing.Size(48, 43);
            this.buttonBaja.TabIndex = 3;
            this.buttonBaja.Text = "-";
            this.buttonBaja.UseVisualStyleBackColor = true;
            this.buttonBaja.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.Location = new System.Drawing.Point(491, 153);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(48, 43);
            this.button11.TabIndex = 2;
            this.button11.Text = "M";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button9
            // 
            this.button9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button9.BackgroundImage")));
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(491, 37);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(48, 43);
            this.button9.TabIndex = 0;
            this.button9.Text = "+";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            this.button9.DragOver += new System.Windows.Forms.DragEventHandler(this.button9_DragOver);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.SteelBlue;
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(755, 493);
            this.tabPage2.TabIndex = 5;
            this.tabPage2.Text = "Herramientas2";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.textBDesc);
            this.groupBox1.Controls.Add(this.textBDisp);
            this.groupBox1.Controls.Add(this.textBCant);
            this.groupBox1.Controls.Add(this.textBID);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.textBHerramientas);
            this.groupBox1.Controls.Add(this.listBoxHerramientas);
            this.groupBox1.Controls.Add(this.buttonHDel);
            this.groupBox1.Controls.Add(this.buttonHMod);
            this.groupBox1.Controls.Add(this.buttonHAdd);
            this.groupBox1.Location = new System.Drawing.Point(20, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(660, 244);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(57, 16);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(136, 13);
            this.label27.TabIndex = 22;
            this.label27.Text = "Busqueda de Herramienta :";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(351, 284);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(0, 13);
            this.label28.TabIndex = 21;
            // 
            // textBDesc
            // 
            this.textBDesc.Location = new System.Drawing.Point(321, 32);
            this.textBDesc.Name = "textBDesc";
            this.textBDesc.Size = new System.Drawing.Size(151, 20);
            this.textBDesc.TabIndex = 19;
            // 
            // textBDisp
            // 
            this.textBDisp.Location = new System.Drawing.Point(321, 130);
            this.textBDisp.Name = "textBDisp";
            this.textBDisp.Size = new System.Drawing.Size(151, 20);
            this.textBDisp.TabIndex = 18;
            // 
            // textBCant
            // 
            this.textBCant.Location = new System.Drawing.Point(321, 75);
            this.textBCant.Name = "textBCant";
            this.textBCant.Size = new System.Drawing.Size(151, 20);
            this.textBCant.TabIndex = 17;
            // 
            // textBID
            // 
            this.textBID.Location = new System.Drawing.Point(321, 174);
            this.textBID.Name = "textBID";
            this.textBID.Size = new System.Drawing.Size(151, 20);
            this.textBID.TabIndex = 16;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(243, 35);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(76, 13);
            this.label26.TabIndex = 15;
            this.label26.Text = "Herramienta  : ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(243, 133);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 13);
            this.label12.TabIndex = 14;
            this.label12.Text = "Disponible : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(243, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Cantidad : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(243, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "IDHerramienta :";
            // 
            // textBHerramientas
            // 
            this.textBHerramientas.Location = new System.Drawing.Point(38, 32);
            this.textBHerramientas.Name = "textBHerramientas";
            this.textBHerramientas.Size = new System.Drawing.Size(184, 20);
            this.textBHerramientas.TabIndex = 11;
            this.textBHerramientas.TextChanged += new System.EventHandler(this.textBHerramientas_TextChanged);
            // 
            // listBoxHerramientas
            // 
            this.listBoxHerramientas.FormattingEnabled = true;
            this.listBoxHerramientas.Location = new System.Drawing.Point(38, 69);
            this.listBoxHerramientas.Name = "listBoxHerramientas";
            this.listBoxHerramientas.Size = new System.Drawing.Size(184, 134);
            this.listBoxHerramientas.TabIndex = 10;
            this.listBoxHerramientas.DoubleClick += new System.EventHandler(this.listBoxHerramientas_DoubleClick);
            // 
            // buttonHDel
            // 
            this.buttonHDel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHDel.Location = new System.Drawing.Point(508, 91);
            this.buttonHDel.Name = "buttonHDel";
            this.buttonHDel.Size = new System.Drawing.Size(48, 43);
            this.buttonHDel.TabIndex = 9;
            this.buttonHDel.Text = "-";
            this.buttonHDel.UseVisualStyleBackColor = true;
            this.buttonHDel.Click += new System.EventHandler(this.buttonHDel_Click);
            // 
            // buttonHMod
            // 
            this.buttonHMod.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHMod.Location = new System.Drawing.Point(508, 151);
            this.buttonHMod.Name = "buttonHMod";
            this.buttonHMod.Size = new System.Drawing.Size(48, 43);
            this.buttonHMod.TabIndex = 8;
            this.buttonHMod.Text = "M";
            this.buttonHMod.UseVisualStyleBackColor = true;
            this.buttonHMod.Click += new System.EventHandler(this.buttonHMod_Click);
            // 
            // buttonHAdd
            // 
            this.buttonHAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonHAdd.BackgroundImage")));
            this.buttonHAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHAdd.Location = new System.Drawing.Point(508, 32);
            this.buttonHAdd.Name = "buttonHAdd";
            this.buttonHAdd.Size = new System.Drawing.Size(48, 43);
            this.buttonHAdd.TabIndex = 7;
            this.buttonHAdd.Text = "+";
            this.buttonHAdd.UseVisualStyleBackColor = true;
            this.buttonHAdd.Click += new System.EventHandler(this.button14_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(69, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(114, 13);
            this.label11.TabIndex = 0;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 31);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(75, 13);
            this.label19.TabIndex = 1;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 70);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(55, 13);
            this.label20.TabIndex = 2;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(9, 47);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(235, 20);
            this.textBox16.TabIndex = 5;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(9, 86);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(52, 20);
            this.textBox17.TabIndex = 6;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(106, 118);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 32);
            this.button7.TabIndex = 7;
            this.button7.Text = "Alta";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(7, 32);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(235, 20);
            this.textBox18.TabIndex = 0;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(7, 58);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(235, 121);
            this.listBox1.TabIndex = 1;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(106, 185);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 35);
            this.button8.TabIndex = 2;
            this.button8.Text = "Baja";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 258);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 13);
            this.label1.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 291);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 13);
            this.label2.TabIndex = 4;
            // 
            // Mantenimiento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(791, 546);
            this.Controls.Add(this.tabControl1);
            this.Name = "Mantenimiento";
            this.Text = "Mantenimiento";
            this.Load += new System.EventHandler(this.Mantenimiento_Load);
            this.tabPage1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPagPersonal.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPagPersonal;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ListBox listBEmpleados;
        private System.Windows.Forms.Button buttonBaja;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.ComboBox comboBNivel;
        private System.Windows.Forms.TextBox textBContraseña;
        private System.Windows.Forms.TextBox textBApellido;
        private System.Windows.Forms.TextBox textBNombre;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBLegajo;
        private System.Windows.Forms.TextBox textBxEmpleado;
        private System.Windows.Forms.TextBox textBNivel;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBHerramientas;
        private System.Windows.Forms.ListBox listBoxHerramientas;
        private System.Windows.Forms.Button buttonHDel;
        private System.Windows.Forms.Button buttonHMod;
        private System.Windows.Forms.Button buttonHAdd;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBDesc;
        private System.Windows.Forms.TextBox textBDisp;
        private System.Windows.Forms.TextBox textBCant;
        private System.Windows.Forms.TextBox textBID;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}