﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace acceso
{
    public partial class Estado : Form
    {
        public Estado()
        {
            InitializeComponent();
            //  AccesoDB estados = new AccesoDB();
              //List<string>[] lista = new List<string>[1];
              //int largo = Convert.ToInt32(lista[0].Count);
             // MessageBox.Show(largo.ToString());

           /*  for (int l = 0; l < 2; l++)
              {
                  comboBox1.Items.Add(lista[0][l]);
              }
           */
            
        }

        private void estate_Load(object sender, EventArgs e)
        {
                    

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {




        }

        private void button1_Click(object sender, EventArgs e)
        {
            ListView1.Items.Clear();
          string format = "yyyy-MM-dd HH:MM:ss";
            string fecha = dateTimePicker1.Value.ToString(format);
            string fecha2 = dateTimePicker2.Value.ToString(format);  
            string estado = (comboBox1.Text);


          //  DateTime fech = Convert.ToDateTime(fecha);
           // DateTime dt = Convert.ToDateTime(fecha);
          //  MessageBox.Show("ver" + dt );
           // MessageBox.Show("fecha forateada " + fech);
            MessageBox.Show("la fecha desde es " + fecha);                     
            MessageBox.Show("la fecha hasta es " + fecha2 );          
                // MessageBox.Show(estado);



            List<string>[] listaPrestamos = new List<string>[6];
            AccesoDB st = new AccesoDB();
            listaPrestamos = st.consultarEstado(fecha, fecha2, estado);
          
           int ll = Convert.ToInt32(listaPrestamos[1].Count);
           // int ll = 3;
            MessageBox.Show("La cantidad de registros validos son : " + ll);
            for (int i = 0; i < ll; i++)

             {
                ListViewItem lvi = new ListViewItem(listaPrestamos[0][i]);
                lvi.SubItems.Add(listaPrestamos[1][i]);
                lvi.SubItems.Add(listaPrestamos[2][i]);
                lvi.SubItems.Add(listaPrestamos[3][i]);
               // lvi.SubItems.Add(listaPrestamos[4][i]);
               // lvi.SubItems.Add(listaPrestamos[5][i]);
                ListView1.Items.Add(lvi);
             }

            

            /*catch (MySqlException ex)
             {
                MessageBox.Show("error"+ ex);
             }
             * */

           
        }
        


        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_MouseClick(object sender, MouseEventArgs e)
        {
          
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            listViewPrinter printer = new listViewPrinter(ListView1, new Point(50, 50), chkBorder.Checked, ListView1.Groups.Count > 0, " el reporte ");
            printer.print();
          
       
        }
    }
}