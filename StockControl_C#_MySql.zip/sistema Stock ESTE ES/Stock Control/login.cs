﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace acceso
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
            this.ActiveControl = comboBox1;
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void login_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void bSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bIngresar_Click(object sender, EventArgs e)
        {
             int bloqueduser=-1;
             if (textBox2.Text == bloqueduser.ToString())
             {

                 MessageBox.Show("Usuario NO HABILITADO");
                 return;
             }
             else
             {
                 try
                 {
                     MySqlConnection con = new MySqlConnection("server=localhost;User Id=root;database=stockcontrol");

                     con.Open(); //Abrimos la conexion creada.
                     MySqlCommand cmd = new MySqlCommand("SELECT * FROM usuarios WHERE legajo='" + comboBox1.Text + "'AND password='" + textBox2.Text + "' ", con); //Realizamos una selecion de la tabla usuarios.



                     MySqlDataReader leer = cmd.ExecuteReader();


                     if (comboBox1.Text.Length == 0)
                     {
                         MessageBox.Show("Error - Debe ingresar el usuario");
                     }
                     else


                         if (textBox2.Text.Length == 0)
                         {
                             MessageBox.Show("Error - Debe ingresar la contraseña");
                         }

                         else

                             if (leer.Read()) //Si el usuario es correcto nos abrira la otra ventana.
                             {

                                 Principal frm = new Principal();
                                 frm.Show();
                                 //this.Hide();
                                 MessageBox.Show("Bienvenido!");
                             }
                             else //Si no lo es mostrara este mensaje.
                                 MessageBox.Show("Error - Usuario/Contraseña Incorrectos");
                     con.Close(); //Cerramos la conexion.
                 }
                 catch //(Exception ex)
                 {
                     MessageBox.Show("Revise la conexion con el servidor");


                    Principal frm = new Principal();
                     frm.Show();
                     //this.Hide();
                     MessageBox.Show("Bienvenido!");
                    
                 }

             }
            
            //string usuario = this.comboBox1.Text;
            //string pass = this.textBox2.Text;
            

            //Principal frm = new Principal();
            //frm.Show();
            //MessageBox.Show("Bienvenido!");

         /* try
             {
                // ESTA ES LA FORMA COMO DEBE LLAMAR AL METODO OK.
                
               AccesoDB adb = new AccesoDB();
              int i = adb.UsuariosLogin(usuario, pass , tipo);
                  
             if (i > 0)
              {
            
                MessageBox.Show("el usuario ha sido correctamente ingresado");
              }

            else
                {
                    MessageBox.Show("el usuario ha sido incorrectamente ingresado");
                }
                //____________________________________________________
               

             if (usuario.Length == 0)
                    MessageBox.Show("Debe ingresar un usuario");
                else
             if (pass.Length == 0)
                    MessageBox.Show("Debe ingresar una password");
                else 
             if (tipo.Length == 0)
                MessageBox.Show("Debe seleccionar un tipo de usuario");
                else
                    {
                     Principal frm = new Principal();
                     frm.Show();
                     MessageBox.Show("Bienvenido!");
                    }
              }

          catch
                {
                MessageBox.Show("un eror ha ocurrido");
                }
          */ 
         
            }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Principal frm = new Principal();
            frm.Show();
            //this.Hide();
            MessageBox.Show("Bienvenido Programador!");
        }
    }
}
