﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Diagnostics;
using System.Configuration;
using System.Data;
using System.IO;
using System.Drawing;
using System.Drawing.Printing;
using Microsoft.VisualBasic;


namespace acceso
{
    public class listViewPrinter
    {

        private ListView lv;
        private Point location;
        private Boolean border;
        private Boolean hasGroups;
        private string title;
        private int titleHeight;

        private PrintDocument pd = new PrintDocument();

        public listViewPrinter(ListView lv, Point location, bool border, bool hasGroups, string title)
        {
            this.lv = lv;
            this.location = location;
            this.border = border;
            this.hasGroups = hasGroups;
            this.title = title;
            titleHeight = !string.IsNullOrEmpty(title) ? lv.FindForm().CreateGraphics().MeasureString(title, new Font(lv.Font.Name, 25)).ToSize().Height : 0;
            pd.BeginPrint += pd_BeginPrint;
            pd.PrintPage += pd_PrintPage;
        }

        public void print()
        {
            //pd.Print()
            PrintPreviewDialog ppd = new PrintPreviewDialog();
            ppd.Document = pd;
            ppd.WindowState = FormWindowState.Maximized;
            ppd.ShowDialog();
        }

        /// <summary>
        /// structure to hold printed page details
        /// </summary>
        /// <remarks></remarks>
        private struct pageDetails
        {
            public int columns;
            public int rows;
            public int startCol;
            public int startRow;
            public List<int> headerIndices;
        }
        /// <summary>
        /// dictionary to hold printed page details, with index key
        /// </summary>
        /// <remarks></remarks>

        private Dictionary<int, pageDetails> pages;
        int maxPagesWide;

        int maxPagesTall;

        ListViewItem[] items;

        /// <summary>
        /// the majority of this Sub is calculating printed page ranges
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <remarks></remarks>
        private void pd_BeginPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            //'this removes the printed page margins
            pd.OriginAtMargins = true;
            pd.DefaultPageSettings.Margins = new System.Drawing.Printing.Margins(location.X, location.X, location.Y, location.Y);

            pages = new Dictionary<int, pageDetails>();

            int maxWidth = Convert.ToInt32(pd.DefaultPageSettings.PrintableArea.Width) - (pd.DefaultPageSettings.Margins.Left + pd.DefaultPageSettings.Margins.Right + 40);
            int maxHeight = Convert.ToInt32(pd.DefaultPageSettings.PrintableArea.Height - (titleHeight + 12)) - (pd.DefaultPageSettings.Margins.Top + pd.DefaultPageSettings.Margins.Bottom + 40);

            int pageCounter = 0;
            pages.Add(pageCounter, new pageDetails { headerIndices = new List<int>() });

            int columnCounter = 0;

            int columnSum = 0;

            for (int c = 0; c <= lv.Columns.Count - 1; c++)
            {
                if (columnSum + lv.Columns[c].Width < maxWidth)
                {
                    columnSum += lv.Columns[c].Width;
                    columnCounter += 1;
                }
                else
                {
                    pages[pageCounter] = new pageDetails
                    {
                        columns = columnCounter,
                        rows = 0,
                        startCol = pages[pageCounter].startCol,
                        headerIndices = pages[pageCounter].headerIndices
                    };
                    columnSum = lv.Columns[c].Width;
                    columnCounter = 1;
                    pageCounter += 1;
                    pages.Add(pageCounter, new pageDetails
                    {
                        startCol = c,
                        headerIndices = new List<int>()
                    });
                }
                if (c == lv.Columns.Count - 1)
                {
                    if (pages[pageCounter].columns == 0)
                    {
                        pages[pageCounter] = new pageDetails
                        {
                            columns = columnCounter,
                            rows = 0,
                            startCol = pages[pageCounter].startCol,
                            headerIndices = pages[pageCounter].headerIndices
                        };
                    }
                }
            }

            maxPagesWide = pages.Keys.Max() + 1;

            pageCounter = 0;

            int rowCounter = 0;
            int counter = 0;

            int itemHeight = lv.GetItemRect(0).Height;

            int rowSum = itemHeight;

            if (hasGroups)
            {
                for (int g = 0; g <= lv.Groups.Count - 1; g++)
                {
                    rowSum += itemHeight + 6;
                    pages[pageCounter].headerIndices.Add(counter);
                    for (int r = 0; r <= lv.Groups[g].Items.Count - 1; r++)
                    {
                        counter += 1;
                        if (rowSum + itemHeight < maxHeight)
                        {
                            rowSum += itemHeight;
                            rowCounter += 1;
                        }
                        else
                        {
                            pages[pageCounter] = new pageDetails
                            {
                                columns = pages[pageCounter].columns,
                                rows = rowCounter,
                                startCol = pages[pageCounter].startCol,
                                startRow = pages[pageCounter].startRow,
                                headerIndices = pages[pageCounter].headerIndices
                            };
                            for (int x = 1; x <= maxPagesWide - 1; x++)
                            {
                                pages[pageCounter + x] = new pageDetails
                                {
                                    columns = pages[pageCounter + x].columns,
                                    rows = rowCounter,
                                    startCol = pages[pageCounter + x].startCol,
                                    startRow = pages[pageCounter].startRow,
                                    headerIndices = pages[pageCounter].headerIndices
                                };
                            }

                            pageCounter += maxPagesWide;
                            for (int x = 0; x <= maxPagesWide - 1; x++)
                            {
                                pages.Add(pageCounter + x, new pageDetails
                                {
                                    columns = pages[x].columns,
                                    rows = 0,
                                    startCol = pages[x].startCol,
                                    startRow = counter - 1,
                                    headerIndices = new List<int>()
                                });
                            }

                            rowSum = itemHeight * 2 + itemHeight + 6;
                            rowCounter = 1;
                        }
                        if (counter == lv.Items.Count)
                        {
                            for (int x = 0; x <= maxPagesWide - 1; x++)
                            {
                                if (pages[pageCounter + x].rows == 0)
                                {
                                    pages[pageCounter + x] = new pageDetails
                                    {
                                        columns = pages[pageCounter + x].columns,
                                        rows = rowCounter,
                                        startCol = pages[pageCounter + x].startCol,
                                        startRow = pages[pageCounter + x].startRow,
                                        headerIndices = pages[pageCounter + x].headerIndices
                                    };
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                for (int r = 0; r <= lv.Items.Count - 1; r++)
                {
                    counter += 1;
                    if (rowSum + itemHeight < maxHeight)
                    {
                        rowSum += itemHeight;
                        rowCounter += 1;
                    }
                    else
                    {
                        pages[pageCounter] = new pageDetails
                        {
                            columns = pages[pageCounter].columns,
                            rows = rowCounter,
                            startCol = pages[pageCounter].startCol,
                            startRow = pages[pageCounter].startRow
                        };
                        for (int x = 1; x <= maxPagesWide - 1; x++)
                        {
                            pages[pageCounter + x] = new pageDetails
                            {
                                columns = pages[pageCounter + x].columns,
                                rows = rowCounter,
                                startCol = pages[pageCounter + x].startCol,
                                startRow = pages[pageCounter].startRow
                            };
                        }

                        pageCounter += maxPagesWide;
                        for (int x = 0; x <= maxPagesWide - 1; x++)
                        {
                            pages.Add(pageCounter + x, new pageDetails
                            {
                                columns = pages[x].columns,
                                rows = 0,
                                startCol = pages[x].startCol,
                                startRow = counter - 1
                            });
                        }

                        rowSum = itemHeight * 2;
                        rowCounter = 1;
                    }
                    if (counter == lv.Items.Count)
                    {
                        for (int x = 0; x <= maxPagesWide - 1; x++)
                        {
                            if (pages[pageCounter + x].rows == 0)
                            {
                                pages[pageCounter + x] = new pageDetails
                                {
                                    columns = pages[pageCounter + x].columns,
                                    rows = rowCounter,
                                    startCol = pages[pageCounter + x].startCol,
                                    startRow = pages[pageCounter + x].startRow
                                };
                            }
                        }
                    }
                }

            }

            maxPagesTall = pages.Count / maxPagesWide;

            if (hasGroups)
            {
                items = new ListViewItem[] { };
                foreach (ListViewGroup g in lv.Groups)
                {
                    items = items.Concat(g.Items.Cast<ListViewItem>().ToArray()).ToArray();
                }
            }
            else
            {
                items = lv.Items.Cast<ListViewItem>().ToArray();
            }

        }
        int startPage = 0;

        //int static_pd_PrintPage_startPage;
        private void pd_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            StringFormat sf = new StringFormat();
            sf.Alignment = StringAlignment.Center;
            sf.LineAlignment = StringAlignment.Center;

            Rectangle r2 = new Rectangle(location, new Size(lv.Columns.Cast<ColumnHeader>().Skip(pages[0].startCol).Take(pages[0].columns).Sum((ColumnHeader ch) => ch.Width), titleHeight));

            e.Graphics.DrawString(title, new Font(lv.Font.Name, 25), Brushes.Black, r2, sf);

            sf.Alignment = StringAlignment.Near;

            int startX = location.X;
            int startY = location.Y + titleHeight + 12;

            int itemHeight = lv.GetItemRect(0).Height;

            Point bottomRight;

            for (int p = startPage; p <= pages.Count - 1; p++)
            {
                startX = location.X;
                startY = location.Y + titleHeight + 12;

                Rectangle cell = default(Rectangle);

                for (int c = pages[p].startCol; c <= pages[p].startCol + pages[p].columns - 1; c++)
                {
                    cell = new Rectangle(startX, startY, lv.Columns[c].Width, itemHeight);
                    e.Graphics.FillRectangle(new SolidBrush(SystemColors.ControlLight), cell);
                    e.Graphics.DrawRectangle(Pens.Black, cell);
                    e.Graphics.DrawString(lv.Columns[c].Text, lv.Font, Brushes.Black, cell, sf);
                    startX += lv.Columns[c].Width;
                }

                startY += itemHeight;
                startX = location.X;

                for (int r = pages[p].startRow; r <= pages[p].startRow + pages[p].rows - 1; r++)
                {
                    startX = location.X;
                    if (hasGroups)
                    {
                        if (r == pages[p].startRow | pages[p].headerIndices.Contains(r))
                        {
                            cell = new Rectangle(startX + 20, startY + 6, lv.Columns.Cast<ColumnHeader>().Skip(pages[p].startCol).Take(pages[p].columns).Sum((ColumnHeader ch) => ch.Width), itemHeight);
                            e.Graphics.DrawString(items[r].Group.Header, new Font(lv.Font, FontStyle.Bold), Brushes.SteelBlue, cell, sf);
                            e.Graphics.DrawLine(new Pen(Color.SteelBlue, 2), startX + 20 + e.Graphics.MeasureString(items[r].Group.Header, new Font(lv.Font, FontStyle.Bold)).Width + 12, cell.Top + 3 + cell.Height / 2, cell.Right - 20, cell.Top + 3 + cell.Height / 2);
                            startY += itemHeight + 6;
                        }
                    }
                    for (int c = pages[p].startCol; c <= pages[p].startCol + pages[p].columns - 1; c++)
                    {
                        cell = new Rectangle(startX, startY, lv.Columns[c].Width, itemHeight);
                        e.Graphics.DrawString(items[r].SubItems[c].Text, lv.Font, Brushes.Black, cell, sf);
                        if (lv.GridLines)
                        {
                            e.Graphics.DrawRectangle(Pens.Black, cell);
                        }
                        startX += lv.Columns[c].Width;
                    }
                    startY += itemHeight;
                    if (r == pages[p].startRow + pages[p].rows - 1)
                    {
                        bottomRight = new Point(startX, startY);
                        if (border)
                        {
                            e.Graphics.DrawRectangle(Pens.Black, new Rectangle(location, new Size(bottomRight.X - location.X, bottomRight.Y - location.Y)));
                        }
                    }

                }

                if (p != pages.Count - 1)
                {
                    startPage = p + 1;
                    e.HasMorePages = true;
                    return;
                }
                else
                {
                    startPage = 0;
                }

            }

        }
        //static bool InitStaticVariableHelper(Microsoft.VisualBasic.CompilerServices.StaticLocalInitFlag flag)
        //{
        //    if (flag.State == 0)
        //    {
        //        flag.State = 2;
        //        return true;
        //    }
        //    else if (flag.State == 2)
        //    {
        //        throw new Microsoft.VisualBasic.CompilerServices.IncompleteInitialization();
        //    }
        //    else
        //    {
        //        return false;
        //    }
        //}

    }
   /// <summary>
   /// 
   /// </summary>
    class AccesoDB
    {
        private MySqlConnection conexión;
        private string servidor;
        private string baseDeDatos;
        private string usuariobd;
        private string passwordbd;


        //Constructor
        public AccesoDB()
        {
            Initialize();
        }
        //Inicializar valores
        private void Initialize()
        {
            servidor = "localhost";
            baseDeDatos = "stockcontrol";
            usuariobd = "root";
            passwordbd = "";
            string stringDeConexion;
            // stringDeConexion = "SERVER=" + servidor + ";" + "DATABASE=" + baseDeDatos + ";" + "UID=" + usuariobd + ";" + "PASSWORD" + passwordbd + ";";
            stringDeConexion = "SERVER=" + servidor + ";" + "DATABASE=" +
            baseDeDatos + ";" + "UID=" + usuariobd + ";" + "PASSWORD=" + passwordbd + ";";

            conexión = new MySqlConnection(stringDeConexion);
        }


        //login de usuarios -----------------------------------------------------------------------------
        public int UsuariosLogin(string usuario, string password, string tipo)
        {

            MySqlConnection cn = new MySqlConnection("conexión");
            MySqlCommand cmd = new MySqlCommand("sp_usuarios_login", cn);

            cmd.Parameters.AddWithValue("@Usuario", usuario);

            cmd.Parameters.AddWithValue("@pass", password);

            cmd.Parameters.AddWithValue("@tipo", tipo);

            int i = int.Parse(cmd.ExecuteScalar().ToString());
            MessageBox.Show("en el login");
            return i;

        }

        //abrirConexion----------------------------------------------------------------------------
        public bool AbrirConexion()
        {
            try
            {
                conexión.Open();
                // MessageBox.Show("conexion exitosa");
                return true;

            }
            catch (MySqlException ex)
            {
                //Se manejan los errores en base el número de error.
                //En este caso
                //0: No se puede conectar con el servidor.
                //1045: Nombre y/o userid no válidos.

                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("No se puede conectar con el servidor.  Contacte con Mesa de Ayuda");
                        break;

                    case 1045:
                        MessageBox.Show("Nombre y/o usuario no válidos, intente nuevamente");
                        break;
                }
                return false;

            }
            // throw new NotImplementedException(); y esto que es??
        }

        /* BackUp de base de datos importa exporta 
           La siguiente función  requiere 2 parametros la ruta mysqldump.exe  y el nombre de la base de datos......
       */

        public void DataBaseBackup(string ExeLocation, string DBName)
        {

            try
            {
                string tmestr = "";
                tmestr = DBName + "-" + DateTime.Now.ToShortDateString() + ".sql";
                tmestr = tmestr.Replace("/", "-");
                tmestr = "d:/" + tmestr;
                StreamWriter file = new StreamWriter(tmestr);
                ProcessStartInfo proc = new ProcessStartInfo();
                string cmd = string.Format(@"-u{0} -p{1} -h{2} {3}", "root", "", "localhost", DBName);
                proc.FileName = ExeLocation;
                proc.RedirectStandardInput = false;
                proc.RedirectStandardOutput = true;
                proc.Arguments = cmd;
                proc.UseShellExecute = false;
                Process p = Process.Start(proc);
                string res;
                res = p.StandardOutput.ReadToEnd();
                file.WriteLine(res);
                p.WaitForExit();
                file.Close();
                MessageBox.Show("Backup Completed");
            }

            catch (IOException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }

        }



        public void importar(string ruteImp )
        {
            string constring = "server=localhost;user=root;pwd=; database= controlstock;";
           //string file = "D:\\backup.sql";
            string file = ruteImp;
            using (MySqlConnection conn = new MySqlConnection(constring))
            {
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    using (MySqlBackup mb = new MySqlBackup(cmd))
                    {
                       
                        
                            cmd.Connection = conn;
                            conn.Open();
                            mb.ImportFromFile(file);
                            conn.Close();
                            MessageBox.Show("Se ha importado exitosamente!");                                                                   
                    }             
                }
            }
        }


        public void Exportar(string rutexp)
        {
            string constring = "server=localhost;user=root;pwd=;database=stockcontrol;";
            //DateTime date = new DateTime();
            //string file = "D:\\backup3.sql";
            DateTime backupTime = DateTime.Now;

            int year = backupTime.Year;
            int month = backupTime.Month;
            int day = backupTime.Day;
           
            int num = 0;
             num++;
             string file = rutexp + "\\" + "CtrlStkDB-" + year + "-" + day + "-" + month + ".SQL";
            using (MySqlConnection conn = new MySqlConnection(constring))
            {
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    using (MySqlBackup mb = new MySqlBackup(cmd))
                    {
                        cmd.Connection = conn;
                        conn.Open();
                        mb.ExportToFile(file);
                        conn.Close();
                    }
                }
            }
        
        }
        //Cerrar la conexion  a la base de datos-------------------------------------------------------
        public void CerrarConexion()
        {
            try
            {
                conexión.Close();
                //return true;
            }

            catch (MySqlException ex)
            {
                int errorcode = ex.Number;
                MessageBox.Show(ex.Message);

                //return false;

            }
        }

        //Verificacion de la conexion------------------------------------------------
        public List<string> Verificación(ref bool acceso, string servidor, string usuario, string password, string baseDatos)
        {
            List<string> query = new List<string>();

            string cs = @"server=" + servidor + ";userid=" + usuario +
                              ";password=" + password + ";database=" + baseDatos + ";";

            MySqlConnection conn = null;

            try
            {
                conn = new MySqlConnection(cs);
                conn.Open();

                query.Add("ServerVersión:     " + conn.ServerVersion);
                query.Add("String:     " + conn.ConnectionString);
                query.Add("Timeout:     " + conn.ConnectionTimeout);
                query.Add("Container:     " + conn.Container);
                query.Add("Database:     " + conn.Database);
                query.Add("DataSource:     " + conn.DataSource);
                query.Add("ServerThread:     " + conn.ServerThread);
                query.Add("Site:     " + conn.Site);
                query.Add("State:     " + conn.State);
                query.Add("UserCompression:     " + conn.UseCompression);
                //string  est = Convert.ToString(conn.State);
                // MessageBox.Show(est);
                // if(est== true)
                /*{
                    
                }
                acceso = true;
               }
                 */
                return query;

            }
            catch (MySqlException excepción)
            //catch (MySqlException)
            {
                acceso = false;

                query.Add("ServerVersión:     " + excepción);
                return query;
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }

            }

        }

        public void altaUsuarios(int leg, string nom, string apell, int nivel, int contra)
        {
            string query = "INSERT INTO usuarios " +
                "(legajo,nombre,apellido,nivelUsuario_codigo,password)" +
                "VALUES(@l,@n,@a,@niv,@contr)";
            if (this.AbrirConexion() == true)
            {
                MySqlCommand cm = new MySqlCommand(query, conexión);
                //EJECUTO EL COMANDO
                cm.Parameters.AddWithValue("@l", leg);
                cm.Parameters.AddWithValue("@n", nom);
                cm.Parameters.AddWithValue("@a", apell);
                cm.Parameters.AddWithValue("@niv", nivel);
                cm.Parameters.AddWithValue("@contr", contra);
                cm.ExecuteNonQuery();
                MessageBox.Show("alta exitosa");

                //Cierra la conexión
                this.CerrarConexion();
            }
        }

        public void altaHerramientas(int idh, int cant, int cantD, string  desh,  string esth , int idest)
        {
            string query = "INSERT INTO herramientas " +
                "(idherramientas,cantidad,cantidadDisponible,descripccion,estado_herramienta , estado_idestado)" +
                "VALUES(@l,@c,@cd,@deh,@ide,@idest)";
            if (this.AbrirConexion() == true)
            {
                MySqlCommand cm = new MySqlCommand(query, conexión);
                //EJECUTO EL COMANDO
                cm.Parameters.AddWithValue("@l", idh);
                cm.Parameters.AddWithValue("@c", cant);
                cm.Parameters.AddWithValue("@cd", cantD);
                cm.Parameters.AddWithValue("@deh", desh);
                cm.Parameters.AddWithValue("@ide", esth);
                cm.Parameters.AddWithValue("@idest", idest);
                cm.ExecuteNonQuery();
                MessageBox.Show("alta exitosa");

                //Cierra la conexión
                this.CerrarConexion();
            }
        }
        //Insertar un usuario----------------------------------------------------------------------
        public void agregarUsuario(int legajo)
        {
            string query = "INSERT FROM usuarios WHERE legajo = " + legajo;

            //abrimos la conexion
            if (this.AbrirConexion() == true)
            {
                MySqlCommand cmd = new MySqlCommand(query, conexión);
                //borro
                cmd.ExecuteNonQuery();
                //cierra la conexion
                this.CerrarConexion();
                return;
            }
            else
                return;

        }

        public void modificIdUsuarioBajaPedidos (int legajo )
        {

            string query = " update pedidos set usuarios_idusuarios = 6     where  usuarios_idusuarios = @lega";

          //string query2 = "update pedidos set estado = @estado where usuarios_idusuarios = @lega";
                           
            if (this.AbrirConexion() == true)
            {
                MySqlCommand cmdpe = new MySqlCommand(query, conexión);
                cmdpe.Parameters.AddWithValue("@lega", legajo);
                //cmdpe.Parameters.AddWithValue("@estado" , estado);
                cmdpe.CommandText = query;
                cmdpe.Connection = conexión;
                cmdpe.ExecuteNonQuery();
               
                this.CerrarConexion();

            }

        }

        public void devuelveTodasHerraPedidos(int idBajaH, string estado)
        {
        }

        public void modificIdHerramientaBajaPedidos(int nHerramienta)
        {
            
            string query = " update pedidos set  herr_idHerr = 8 , descripccion = 'dada de baja'  , estado = 'devuelto'  where  herr_idHerr = @idher";

            //string query2 = "update pedidos set estado = @estado where usuarios_idusuarios = @lega";

            if (this.AbrirConexion() == true)
            {
                MySqlCommand cmdpe = new MySqlCommand(query, conexión);
                cmdpe.Parameters.AddWithValue("@idher", nHerramienta);
              // cmdpe.Parameters.AddWithValue("@estado", estado);
                cmdpe.CommandText = query;
                cmdpe.Connection = conexión;
                cmdpe.ExecuteNonQuery();

                this.CerrarConexion();

            }

        }


        public void devuelveTBajaE(int id, string estado)
        {
             string query = " update pedidos set  estado = @estado    where  usuarios_idusuarios = @id";

            //string query2 = "update pedidos set estado = @estado where usuarios_idusuarios = @lega";

             if (this.AbrirConexion() == true)
             {
                 MySqlCommand cmddb = new MySqlCommand(query, conexión);
                 cmddb.Parameters.AddWithValue("@id", id);
                 cmddb.Parameters.AddWithValue("@estado", estado);
                 // cmdpe.Parameters.AddWithValue("@estado", estado);
                 cmddb.CommandText = query;
                 cmddb.Connection = conexión;
                 cmddb.ExecuteNonQuery();

                 this.CerrarConexion();
             }
        }
        public void devuelveTBajaH(int id, string estado)
        {
            string query = " update pedidos set  estado = @estado    where  herr_idHerr = @id";

            //string query2 = "update pedidos set estado = @estado where usuarios_idusuarios = @lega";

            if (this.AbrirConexion() == true)
            {
                MySqlCommand cmddh = new MySqlCommand(query, conexión);
                cmddh.Parameters.AddWithValue("@id", id);
                cmddh.Parameters.AddWithValue("@estado", estado);
                // cmdpe.Parameters.AddWithValue("@estado", estado);
                cmddh.CommandText = query;
                cmddh.Connection = conexión;
                cmddh.ExecuteNonQuery();

                this.CerrarConexion();
            }
        }
        //Eliminamos un usuario-------------------------------------------------------------------
        public void eliminarUsuario(int legajo)
        {
            
            string query = "DELETE  FROM usuarios WHERE legajo = @legajo";

            //abrimos la conexion
            if (this.AbrirConexion() == true)
            {
                MySqlCommand cmd = new MySqlCommand(query, conexión);
                cmd.Parameters.AddWithValue("@legajo", legajo);
                
                cmd.ExecuteNonQuery();
                //cierra la conexion
                this.CerrarConexion();
                return;
            }
            else
                return;

        }


        public void eliminarHerramienta(int nherra)
        {

            string query = "DELETE  FROM herramientas WHERE idherramientas = @n";

            //abrimos la conexion
            if (this.AbrirConexion() == true)
            {
                MySqlCommand cmd = new MySqlCommand(query, conexión);
                cmd.Parameters.AddWithValue("@n", nherra);

                cmd.ExecuteNonQuery();
                //cierra la conexion
                this.CerrarConexion();
                return;
            }
            else
                return;

        }


     /*   public void backupdb()
        {
            string constring = "server=localhost;user=root;pwd=qwerty;database=test;";
            string file = "C:\\backup.sql";
            using (MySqlConnection conn = new MySqlConnection(constring))
            {
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    using (MySqlBackup mb = new MySqlBackup(cmd))
                    {
                        cmd.Connection = conn;
                        conn.Open();
                        mb.ExportToFile(file);
                        conn.Close();
                    }
                }
            }
        }
        */

        //Consultar legajo--------------------------------------------------------------------
        public List<string>[] ConsultarLegajo()
        {
            string query = "SELECT * FROM usuarios";

            //Crea una lista para almacenar el resultado
            List<string>[] list = new List<string>[3];
            list[0] = new List<string>();
            list[1] = new List<string>();
            list[2] = new List<string>();

            if (this.AbrirConexion() == true)
            {
                MySqlCommand cmd = new MySqlCommand(query, conexión);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    list[0].Add(dataReader["legajo"] + "");
                    list[1].Add(dataReader["nombre"] + "");
                    list[2].Add(dataReader["apellido"] + "");

                }
                dataReader.Close();
                this.CerrarConexion();
                return list;
            }

            else
            {
                MessageBox.Show("CONEXIÓN NO EXITOSA - Comuníquese con Mesa de Ayuda");
                return list;
            }

        }

        public List<string>[] ConsultarLegajoH()
        {
            string query = "SELECT * FROM herramientas";

            //Crea una lista para almacenar el resultado
            List<string>[] list = new List<string>[6];
            list[0] = new List<string>();
            list[1] = new List<string>();
            list[2] = new List<string>();
            list[3] = new List<string>();
            list[4] = new List<string>();
            list[5] = new List<string>();
            

            if (this.AbrirConexion() == true)
            {
                MySqlCommand cmd = new MySqlCommand(query, conexión);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    list[0].Add(dataReader["idherramientas"] + "");
                    list[1].Add(dataReader["cantidad"] + "");
                    list[2].Add(dataReader["cantidadDisponible"] + "");
                    list[3].Add(dataReader["descripccion"] + "");
                    list[4].Add(dataReader["estado_herramienta"] + "");
                    list[5].Add(dataReader["estado_idestado"] + "");
                   

                }
                dataReader.Close();
                this.CerrarConexion();
                return list;
            }

            else
            {
                MessageBox.Show("CONEXIÓN NO EXITOSA - Comuníquese con Mesa de Ayuda");
                return list;
            }

        }

        public List<string>[] consultarEstado(string dateFrom, string dateTo ,string est)
        {
           
           
                //Crea una lista para almacenar el resultado
                List<string>[] list = new List<string>[6];
                list[0] = new List<string>();
                list[1] = new List<string>();
                list[2] = new List<string>();
                list[3] = new List<string>();
                list[4] = new List<string>();
                list[5] = new List<string>();
                //list[6] = new List<string>();
               
            if (this.AbrirConexion() == true)
                {
                 string query = "SELECT idPedidos , descripccion,  usuarios.nombre ,  usuarios.apellido , pedidos.usuarios_legajo " +

                "from pedidos  join usuarios on pedidos.usuarios_legajo = usuarios.legajo " +

                "join usuarios on  pedidos.usuarios_idusuarios = usuarios.legajo  AND estado = @esth  AND fecha BETWEEN  @fFrom AND @fTo  ";  
      
                    MySqlCommand consultaE = new MySqlCommand(query, conexión);
                  consultaE.Parameters.AddWithValue("@esth", est); 
                   consultaE.Parameters.AddWithValue("@fFrom" , dateFrom );
                   consultaE.Parameters.AddWithValue("@fTo", dateTo);

                   string query2 = consultaE.CommandText;
                   foreach (MySqlParameter p in consultaE.Parameters)
                   {
                       query2 = query2.Replace(p.ParameterName, p.Value.ToString());
                       
                   }
                   MessageBox.Show(query2);

                    MySqlDataReader dataReader = consultaE.ExecuteReader();
                    
                    while (dataReader.Read())
                    {
                        list[0].Add(dataReader["idPedidos"] + "");
                        list[1].Add(dataReader["descripccion"] + "");
                        list[2].Add(dataReader["nombre"] + "");
                        list[3].Add(dataReader["apellido"] + "");
                       // list[4].Add(dataReader["nombre"] + "");
                        //list[5].Add(dataReader["apellido"] + "");
                       // list[4].Add(dataReader["estado"] + "");
                        //list[5].Add(dataReader["nombre"] + "");
                        //list[6].Add(dataReader["apellido"] + "");
                        // list[5].Add(dataReader["usuarios_idusuarios"] + "");
                         
                    }

                    dataReader.Close();
                    this.CerrarConexion();
                  
                    return list;
                    
                   }

                else
                {
                    MessageBox.Show("CONEXIÓN NO EXITOSA - Comuníquese con Mesa de Ayuda");
                    return list;
                }

            }
        
        //---------------------------------------finaliza consultarEstado--------------------------------


        public List<string>[] buscarEmpleado(string lega)
        {
            //Crea una lista para almacenar el resultado
            List<string>[] list = new List<string>[5];
            list[0] = new List<string>();
            list[1] = new List<string>();
            list[2] = new List<string>();
            list[3] = new List<string>();
            list[4] = new List<string>();
            if (this.AbrirConexion() == true)
            {
                string consultaEmp = " SELECT * FROM usuarios WHERE legajo like @nemp ";
                MySqlCommand consultaE = new MySqlCommand(consultaEmp, conexión);
                consultaE.Parameters.AddWithValue("@nemp", lega + '%');
                MySqlDataReader dataReader = consultaE.ExecuteReader();
                while (dataReader.Read())
                {
                    list[0].Add(dataReader["legajo"] + "");
                    list[1].Add(dataReader["nombre"] + "");
                    list[2].Add(dataReader["apellido"] + "");
                    list[3].Add(dataReader["nivelUsuario_codigo"] + "");
                    list[4].Add(dataReader["password"] + "");
                    
                }
                dataReader.Close();
                this.CerrarConexion();
                return list;
            }

            else
            {
                MessageBox.Show("CONEXIÓN NO EXITOSA - Comuníquese con Mesa de Ayuda");
                return list;
            }

        }


       public  DataTable Buscarh(int nombre)
       {
         DataTable dt = new DataTable();
         string query = "SELECT descripccion from herramientas WHERE idherramientas = @desc ";
         MySqlCommand consultahe = new MySqlCommand(query, conexión);
         consultahe.Parameters.AddWithValue("@desc", nombre);
         MySqlDataAdapter adapt = new MySqlDataAdapter(consultahe);
         adapt.Fill(dt);
         return dt;
        
     
      }

      


       public DataTable BuscarPañolero(int legajP)
       {
           DataTable dt = new DataTable();
           string query = "SELECT descripccion from herramientas WHERE idherramientas = @desc ";
           MySqlCommand consultahe = new MySqlCommand(query, conexión);
           consultahe.Parameters.AddWithValue("@desc", legajP);
           MySqlDataAdapter adapt = new MySqlDataAdapter(consultahe);
           adapt.Fill(dt);
           return dt;


       }



       public List<string>[] consultarEstados()
       {
           string query = " select * from estado ";
           List<string>[] listEstados = new List<string>[2];
           listEstados[0] = new List<string>();

             if (this.AbrirConexion() == true)
            {
                MySqlCommand cmd = new MySqlCommand(query, conexión);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    listEstados[0].Add(dataReader["idestado"] + "");
                    listEstados[0].Add(dataReader["condicion"] + "");
                }
                dataReader.Close();
                this.CerrarConexion();
                return listEstados;
            }

             else
             {
                 MessageBox.Show("CONEXIÓN NO EXITOSA - Comuníquese con Mesa de Ayuda");
                 return listEstados;
             }

       }
        
        //Consultar herramienta-----------------------------------------------------
        public List<string>[] ConsultarHerramientat()
        {

            string query = " SELECT * FROM herramientas ";
            //Crea una lista para almacenar el resultado
            List<string>[] lherrN = new List<string>[4];
            lherrN[0] = new List<string>();
            lherrN[1] = new List<string>();
            lherrN[2] = new List<string>();
            lherrN[3] = new List<string>();
            lherrN[4] = new List<string>();


            if (this.AbrirConexion() == true)
            {
                MySqlCommand cmd = new MySqlCommand(query, conexión);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    lherrN[0].Add(dataReader["idherramientas"] + "");
                    lherrN[1].Add(dataReader["cantidad"] + "");
                    lherrN[2].Add(dataReader["descripccion"] + "");
                    lherrN[3].Add(dataReader["estado_herramienta"] + "");
                    lherrN[4].Add(dataReader["estado_idestado"] + "");

                }
                dataReader.Close();
                this.CerrarConexion();
                return lherrN;
            }

            else
            {
                MessageBox.Show("CONEXIÓN NO EXITOSA - Comuníquese con Mesa de Ayuda");
                return lherrN;
            }
        }

       

        
            public List<string>[] ConsultarHerramienta2(string articulo)
                {
                    List<string>[] listaherr = new List<string>[6];
                    listaherr[0] = new List<string>();
                    listaherr[1] = new List<string>();
                    listaherr[2] = new List<string>();
                    listaherr[3] = new List<string>();
                    listaherr[4] = new List<string>();
                    listaherr[5] = new List<string>();
                    // MessageBox.Show("aca creo el arraylist donde se carga todo");

                    if (this.AbrirConexion() == true)
                    {

                        string consultaherr = " SELECT * FROM herramientas where descripccion like @desc ";           
               
                        MySqlCommand consultah = new MySqlCommand(consultaherr, conexión);
                        consultah.Parameters.AddWithValue("@desc", articulo + '%');
               
                        MySqlDataReader dataReader = consultah.ExecuteReader();

                        while (dataReader.Read())
                        {
                            //MessageBox.Show("Aca leyendo el data reader");
                            listaherr[0].Add(dataReader["idherramientas"] + "");
                            listaherr[1].Add(dataReader["cantidad"] + "");
                            listaherr[2].Add(dataReader["cantidadDisponible"] + "");
                            listaherr[3].Add(dataReader["descripccion"] + "");
                            listaherr[4].Add(dataReader["estado_herramienta"] + "");
                            listaherr[5].Add(dataReader["estado_idestado"] + "");
                        }
                        dataReader.Close();
                        //Cerrar la conexión
                        this.CerrarConexion();

                        return listaherr;
                    }

                    else
                    {
                        MessageBox.Show("CONEXIÓN NO EXITOSA - Comuníquese con Mesa de Ayuda");
                        return listaherr;
                    }
                }
                //return listaherr;
            // termina el metodo consultaHerramienta
           






        

        //Modificar Estado--------------000000000000000000-----------------------------------------------------------

        public void EstadoHerrPrestar(int   mh, int hp)
        {
            string query = "update herramientas set cantidadDisponible = @cand  where idherramientas = @idHerr";         
            //Abrir conexión
            if (this.AbrirConexion() == true)
            {
                //MessageBox.Show("dentro del if"); Crear el comando mysql
                MySqlCommand consultaEst = new MySqlCommand(query, conexión);
                consultaEst.Parameters.AddWithValue("@cand", mh );
                consultaEst.Parameters.AddWithValue("@idHerr", hp);

                // Asignar el query usando CommandText
                consultaEst.CommandText = query;
                // Asignar la conexión usando Connection
                consultaEst.Connection = conexión;

                // ejecutar el query
                consultaEst.ExecuteNonQuery();

                //cerrar la conexión 
                this.CerrarConexion();
            }
        }


        public void devuelveHerramienta(int nuPedido, int usuariodevuelve , string estado)
        {

            //string devuel = "devuelto";
            string query ="UPDATE pedidos SET estado = @devNoDevt "+
          "  where idPedidos = @nPedido and usuarios_idusuarios = @usua  ";

            if (this.AbrirConexion() == true)
            {
                try
                {
                    MySqlCommand devuel = new MySqlCommand(query, conexión);

                    devuel.Parameters.AddWithValue("@devNoDevt", estado);
                    devuel.Parameters.AddWithValue("@nPedido", nuPedido);
                    devuel.Parameters.AddWithValue("@usua", usuariodevuelve);

                    devuel.CommandText = query;
                    devuel.Connection = conexión;
                    devuel.ExecuteNonQuery();
                    MessageBox.Show("devolución exitosa");
                    this.CerrarConexion();
                }
                catch(MySqlException ex)
                {
                    MessageBox.Show("Ha ocurrido un error" + ex);
                }
                //return;
            }
        
           

        }

        public DataTable BuscarCantidad(int idPedido)
        {
            DataTable dt = new DataTable();
            string query = "SELECT cantidadDisponible from herramientas WHERE idherramientas = @ID ";
            MySqlCommand consultahe = new MySqlCommand(query, conexión);
            consultahe.Parameters.AddWithValue("@ID", idPedido);
            MySqlDataAdapter adapt = new MySqlDataAdapter(consultahe);
            adapt.Fill(dt);
            return dt;


        }
        public void devuelveHerramientaCambiaEStado( int cantD  ,string hID)
        {
            string query = "update herramientas set cantidadDisponible = @cand  where descripccion = @dHerr";
             
            //Abrir conexión
            if (this.AbrirConexion() == true)
            {
                //MessageBox.Show("dentro del if"); Crear el comando mysql
                MySqlCommand consultaEst = new MySqlCommand(query, conexión);
                consultaEst.Parameters.AddWithValue("@cand", cantD);
                consultaEst.Parameters.AddWithValue("@dHerr",hID  );

                // Asignar el query usando CommandText
                consultaEst.CommandText = query;
                // Asignar la conexión usando Connection
                consultaEst.Connection = conexión;

                // ejecutar el query
                consultaEst.ExecuteNonQuery();
                MessageBox.Show("se ha cambiado la cantidad disponible de herramienta");
                //cerrar la conexión 
                this.CerrarConexion();
            }
        }

        /*
                public   DateTime getFechaActual()
                {
                    int anio, dia, mes;
                    DateTime dtFecha;
                    anio = DateTime.Today.Year;
                    mes = DateTime.Today.Month;
                    dia = DateTime.Today.Day;
                    // hora = DateTime.Today.Hour;
                    dtFecha = new DateTime(anio, mes, dia);
                    return dtFecha;

                }
         * */
        //------------------------GUARDAR REGISTRO PEDIDOS-------------------------------
        /*  public void agregarUsuario(int legajo)
          {
            

              //abrimos la conexion
              if (this.AbrirConexion() == true)
              {
                  MySqlCommand cmd = new MySqlCommand(query, conexión);
                  //borro
                  cmd.ExecuteNonQuery();
                  //cierra la conexion
                  this.CerrarConexion();
                  return;
              }
              else
                  return;

          }
          */
        //:_______-

        public void GuardarRegistro(string fecha, int idherr,string descripccion, string estadoh, string estadohe, int legajoU, int codUsuario)
        {

            //  int upedido = BuscaPedido() + 1;
            //upedido++;


            //string descripccion = Buscardescripccion();

            string queryGR = "INSERT INTO pedidos" +
                          " ( fecha,herr_idHerr,descripccion ,estadoH,estado ,usuarios_idusuarios,usuarios_legajo ) " +
                          "VALUES( @fechaHoy,@herramientas_idherramienta,@descripccion,@estadoH,@estadohe,@usuarios_idusuarios ,@usuarios_legajo )";

            if (this.AbrirConexion() == true)
            {
                MySqlCommand cmd = new MySqlCommand(queryGR, conexión);

                //Ejecuta el comando
                cmd.Parameters.AddWithValue("@fechaHoy", fecha);
                cmd.Parameters.AddWithValue("@herramientas_idherramienta", idherr);
                cmd.Parameters.AddWithValue("@descripccion", descripccion);
                cmd.Parameters.AddWithValue("@estadoH", estadoh);
                cmd.Parameters.AddWithValue("@estadohe", estadohe);
                cmd.Parameters.AddWithValue("@usuarios_idusuarios", legajoU);
                cmd.Parameters.AddWithValue("@usuarios_legajo", codUsuario);
                cmd.ExecuteNonQuery();

                //Cierra la conexión
                this.CerrarConexion();
                MessageBox.Show("Aca tendriamos que haber agregado el pedido");
            }

            /*else
            {
                return;
            }
            */


        }
       

        //--- CUENTA LA CANTIDAD DE pedidos --///---////////////////////////////////////////////////////////////////
        private int CuentaRenglones()
        {
            string query = "SELECT Count(*) FROM pedidos";
            int CuentaFilas = -1;

            //Abrir la conexión
            if (this.AbrirConexion() == true)
            {
                //Crear el comando MySql
                MySqlCommand cmd = new MySqlCommand(query, conexión);

                //Ejecutar el escalar (retorna un solo valor)
                CuentaFilas = int.Parse(cmd.ExecuteScalar() + "");

                //Cerrar la conexión
                this.CerrarConexion();

                return CuentaFilas;
            }
            else
            {
                return CuentaFilas;
            }

        }
        ////-----------------------------------------------------------------------------------
        //--- BUSCA EL ÚLTIMO Pedido -----
        public int BuscaPedido()
        {
            int npedido = CuentaRenglones();

            if (npedido == 0)
            { return 1000; }
            else
            {
                string query = "SELECT MAX(id_pedidos) FROM pedidos";

                //Abrir la conexión
                if (this.AbrirConexion() == true)
                {
                    //Crear el comando MySql
                    MySqlCommand cmd = new MySqlCommand(query, conexión);

                    //Ejecutar el escalar (retorna un solo valor)
                    npedido = int.Parse(cmd.ExecuteScalar().ToString());
                    //Cerrar la conexión
                    this.CerrarConexion();

                    return npedido;
                }
                else
                {
                    MessageBox.Show("CONEXIÓN NO EXITOSA - Comuníquese con Mesa de Ayuda");
                    return npedido;
                }
            }

        }

        public List<string>[] consultaEstadoPedidos(int nUsuario)
        {
            string numeroHera = Convert.ToString(nUsuario);
            List<string>[] listaPedidos = new List<string>[8];
            listaPedidos[0] = new List<string>();
            listaPedidos[1] = new List<string>();
            listaPedidos[2] = new List<string>();
            listaPedidos[3] = new List<string>();
            listaPedidos[4] = new List<string>();
            listaPedidos[5] = new List<string>();
            listaPedidos[6] = new List<string>();
            listaPedidos[7] = new List<string>();

            if (this.AbrirConexion() == true)
            {
                string query = "SELECT * from pedidos WHERE usuarios_idusuarios = @usu ";
                MySqlCommand consultPedidoSU = new MySqlCommand(query, conexión);
                consultPedidoSU.Parameters.AddWithValue("@usu", nUsuario);
                MySqlDataReader datareader = consultPedidoSU.ExecuteReader();
            
              
                    while (datareader.Read())
                    {
                        //MessageBox.Show("Aca leyendo el data reader");

                        listaPedidos[0].Add(datareader["idPedidos"] + "");
                        listaPedidos[1].Add(datareader["fecha"] + "");
                        listaPedidos[2].Add(datareader["herr_IdHerr"] + "");
                        listaPedidos[3].Add(datareader["descripccion"] + "");
                        listaPedidos[4].Add(datareader["estadoH"] + "");
                        listaPedidos[5].Add(datareader["estado"] + "");
                        listaPedidos[6].Add(datareader["usuarios_idusuarios"] + "");
                        listaPedidos[7].Add(datareader["usuarios_legajo"] + "");                                        
                    }

                datareader.Close();
                //Cerrar la conexión
                this.CerrarConexion();

                return listaPedidos;
            }

            else
            {
                MessageBox.Show("CONEXIÓN NO EXITOSA - Comuníquese con Mesa de Ayuda");
                return listaPedidos;
            }
        }






      //Busca la herramienta por descripccion..
        public List<string>[] ConsultarHerramienta(string articulo)
        {
            string numString = Convert.ToString(articulo); //"1287543.0" will return false for a long          
            List<string>[] listaherr = new List<string>[6];
            listaherr[0] = new List<string>();
            listaherr[1] = new List<string>();
            listaherr[2] = new List<string>();
            listaherr[3] = new List<string>();
            listaherr[4] = new List<string>();
            listaherr[5] = new List<string>();
            // MessageBox.Show("aca creo el arraylist donde se carga todo");
            if (this.AbrirConexion() == true)
            {

                string consultaherr = " SELECT * FROM herramientas where idherramientas like @desc";//'%" + articulo + "%'";            
                MySqlCommand consultah = new MySqlCommand(consultaherr, conexión);
                consultah.Parameters.AddWithValue("@desc", articulo);
                MySqlDataReader dataReader = consultah.ExecuteReader();
                if (dataReader.HasRows)
                {
                    while (dataReader.Read())
                    {
                        //MessageBox.Show("Aca leyendo el data reader");
                        listaherr[0].Add(dataReader["idherramientas"] + "");
                        listaherr[1].Add(dataReader["cantidad"] + "");
                        listaherr[2].Add(dataReader["cantidadDisponible"] + "");
                        listaherr[3].Add(dataReader["descripccion"] + "");
                        listaherr[4].Add(dataReader["estado_herramienta"] + "");
                        listaherr[5].Add(dataReader["estado_idestado"] + "");
                    }
                }
                dataReader.Close();
                //Cerrar la conexión
                this.CerrarConexion();

                return listaherr;
            }

            else
            {
                MessageBox.Show("CONEXIÓN NO EXITOSA - Comuníquese con Mesa de Ayuda");
                return listaherr;
            }
        }


   public List<string>[] buscHerraID(string idHerramienta)
     
    {
         List<string>[] listaHe = new List<string>[6];
            listaHe[0] = new List<string>();
            listaHe[1] = new List<string>();
            listaHe[2] = new List<string>();
            listaHe[3] = new List<string>();
            listaHe[4] = new List<string>();
            listaHe[5] = new List<string>();
            if (this.AbrirConexion() == true)
            {
                string consultahe = " SELECT * FROM herramientas where idherramientas like @idh";//'%" + articulo + "%'";            
                MySqlCommand consultah = new MySqlCommand(consultahe, conexión);
                consultah.Parameters.AddWithValue("@idh", idHerramienta);
                MySqlDataReader dataReader = consultah.ExecuteReader();
                if (dataReader.HasRows)
                {
                    while (dataReader.Read())
                    {
                        //MessageBox.Show("Aca leyendo el data reader");
                        listaHe[0].Add(dataReader["idherramientas"] + "");
                        listaHe[1].Add(dataReader["cantidad"] + "");
                        listaHe[2].Add(dataReader["cantidadDisponible"] + "");
                        listaHe[3].Add(dataReader["descripccion"] + "");
                        listaHe[4].Add(dataReader["estado_herramienta"] + "");
                        listaHe[5].Add(dataReader["estado_idestado"] + "");
                    }
                }
                dataReader.Close();
                //Cerrar la conexión
                this.CerrarConexion();
                
                return listaHe;
                    
            }
            else
            {
                MessageBox.Show("CONEXIÓN NO EXITOSA - Comuníquese con Mesa de Ayuda");
                return listaHe;
            }
    }

 

   /*    public   string buscaHdescripccion(int idh )
        {

            string d = "a";
            if (this.AbrirConexion() == true)
            {
                string result;
                string sql = "SELECT * FROM herramientas where idherramientas = @hID";
               // consultah.Parameters.AddWithValue("@art", art + '%');
                MySqlCommand consulta = new MySqlCommand(sql, conexión);
                consulta.Parameters.AddWithValue("@hID", idh);
                MySqlCommand cmd = new MySqlCommand(sql, conexión);
                result = cmd.ExecuteReader().ToString(); 
                
                if (result != null)
                {
                    d = Convert.ToString(result);
                    MessageBox.Show("el objeto es " + d);

                    
                     return d;
                    //string consultaherr = " SELECT * FROM herramientas where idherramientas = @desc";//'%" + articulo + "%'";            

                }

                else
                {
                    MessageBox.Show("CONEXIÓN NO EXITOSA - Comuníquese con Mesa de Ayuda");
                    return d;
                }


            }
            return d;
        }
        
        */


        // termina el if-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.
        public List<string>[] consultaherramientaId(int art)
        {
            List<string>[] listaid = new List<string>[1];
            listaid[0] = new List<string>();
             if (this.AbrirConexion() == true)
            {

                string consultaherr = " SELECT descripccion FROM herramientas where idherramientas like @art ";
               
               
                MySqlCommand consultah = new MySqlCommand(consultaherr, conexión);
                consultah.Parameters.AddWithValue("@art", art + '%');
               
                MySqlDataReader dataReader = consultah.ExecuteReader();

                while (dataReader.Read())
                {
                    //MessageBox.Show("Aca leyendo el data reader");
                    listaid[0].Add(dataReader["descripccion"] + "");
                }
                dataReader.Close();
                //Cerrar la conexión
                this.CerrarConexion();

                return listaid;
            }

             else
             {
                 MessageBox.Show("CONEXIÓN NO EXITOSA - Comuníquese con Mesa de Ayuda");
                 return listaid;
             }
        }
    }

    //-----------------------aca termina.--------------------




   

    //throw new NotImplementedException();
    // aca termina la clase




    //--------------------------------------------------------------------------------------------

   

      /*  public List<string>[] ConsultarPedidos()
        {
            List<string>[] listaherr = new List<string>[6];
            listaherr[0] = new List<string>();
            listaherr[1] = new List<string>();
            listaherr[2] = new List<string>();
            listaherr[3] = new List<string>();
            listaherr[4] = new List<string>();
            listaherr[5] = new List<string>();
            // MessageBox.Show("aca creo el arraylist donde se carga todo");

            if (this.AbrirConexion() == true)
            {

                string consultaherr = " SELECT * FROM herramientas where descripccion like @desc ";
               
                //'%" + articulo + "%'";//+ '%' ";
                MySqlCommand consultah = new MySqlCommand(consultaherr, conexión);
                consultah.Parameters.AddWithValue("@desc", articulo);
                //consultah.Parameters.AddWithValue("?desc", MySqlDbType.VarChar,200).Value = "%" + articulo + "%";
                //consultah.Parameters.AddWithValue(string ?desc , articulo);
                //Ejecutar el escalar (retorna un solo valor)
                MySqlDataReader dataReader = consultah.ExecuteReader();

                while (dataReader.Read())
                {
                    //MessageBox.Show("Aca leyendo el data reader");
                    listaherr[0].Add(dataReader["idherramientas"] + "");
                    listaherr[1].Add(dataReader["cantidad"] + "");
                    listaherr[2].Add(dataReader["cantidadDisponible"] + "");
                    listaherr[3].Add(dataReader["descripccion"] + "");
                    listaherr[4].Add(dataReader["estado_herramienta"] + "");
                    listaherr[5].Add(dataReader["estado_idestado"] + "");
                }
                dataReader.Close();
                //Cerrar la conexión
                this.CerrarConexion();

                return listaherr;
            }

            else
            {
                MessageBox.Show("CONEXIÓN NO EXITOSA - Comuníquese con Mesa de Ayuda");
                return listaherr;
            }
        }
        //return listaherr;
    }
    //-------------------------------------------------------------------------------
    */









   public static class AutoCompleClass
    {
        /* esto no lo cargué para verlo nomas...
        //metodo para cargar los datos de la bd
        public static DataTable Datos()
        
            DataTable dt = new DataTable();
            MySqlConnection conect = new MySqlConnection(conect.ConnectionString=("server=127.0.0.1;Port=3306;uid=root;pwd=1234;database=MiBase";);
            MySqlConnection _connection.ConnectionString = 
            conexion.ConnectionString = 
       //---------------------------------
             
        MySqlConnection cn;
        MySqlCommand cm;
        MySqlDataAdapter da;
        DataSet ds;
        string sql = "SELECT * FROM alumnos WHERE cursoAcademico=?curso";
        cn = new MySqlConnection("Data Source=servidor;Database=base_de_datos;User ID=usuario; Password=clave; Allow Zero Datetime=True; CHARSET=latin1");
        cn.open();

        cm = new MySqlCommand();
        cm.CommandText = sql;
        cm.CommandType = CommandType.Text;
        cm.Connection = cn;
        cm.Parameters.Add("?curso", MySqlDbType.Int32);
        cm.Parameters["?curso"].Value = 2006;
        da = new MySqlDataAdapter(cm);

        ds= new DataSet();
        da.Fill(ds);
           */
       //----------------------------------------
        
       /*string consultaU = "SELECT * FROM usuarios ";
            MySqlCommand cmd = new MySqlCommand(consultaU, conexion);
           // consultaU.Parameters.AddWithValue("@nomb",user);
            MySqlDataAdapter adapt = new MySqlDataAdapter(cmd);
            adapt.Fill(dt);        
            return dt;
        }

        //metodo para cargar la coleccion de datos para el autocomplete
        public static AutoCompleteStringCollection Autocomplete()
        {
            DataTable dt = Datos();

            AutoCompleteStringCollection coleccion = new AutoCompleteStringCollection();
            //recorrer y cargar los items para el autocompletado
            foreach (DataRow row in dt.Rows)
            {
                coleccion.Add(Convert.ToString(row["nombre"]));
            }

            return coleccion;
        }
*/
    }
}









  

/*
   
    
     {
        
      //metodo para cargar los datos de la bd
      public static Datatable Datos()
      {
          DataTable dt = new DataTable();

          SqlConnection conexion = new SqlConnection(ConfigurationManager.ConnectionStrings["default"].ToString());//cadena conexion

          string consulta = "SELECT * FROM PAISES"; //consulta a la tabla paises
          SqlCommand comando = new SqlCommand(consulta,conexion);

          SqlDataAdapter adap = new SqlDataAdapter(comando);

          adap.Fill(dt);
          return dt;
      }

      //metodo para cargar la coleccion de datos para el autocomplete
      public static AutoCompleteStringCollection Autocomplete()
      {
          DataTable dt = Datos();

          AutoCompleteStringCollection coleccion = new AutoCompleteStringCollection();
          //recorrer y cargar los items para el autocompletado
          foreach (DataRow row in dt.Rows)
          {
              coleccion.Add(Convert.ToString(row["pais"]));
          }

          return coleccion;
      }
  }
     * */
    

       
        /*Guardar registro-------------------------------------------------------------------------
        public void  GuardarRegistroPedido( int id_pedidos   , string turno ,int herramienta_id , int usuarios_idUsuarios , int usuario_legajo)
        {
           // int idRegistro = new idRegistro();
            idRegistro.buscarUltimoN();
                   
    DateTime fechaHoy = DateTime.Today;
            string Usuario = "";
            string query = "INSERT INTO pedidos" +
                           " (legajo,nombre, apellido, edad,cod_carrera,fecha,usuario) " +
                           "VALUES(@Legajo,@Nombre,@Apellido,@Edad,@Cod_Carrera,@Fecha,@Usuario)";

         //string query = "Insert from 
   
        }
    */
        //faltaria:
        
        //Insertar Herramienta en base de datos
        //Modificar eliminar  datos de usuario 
        




/*

     public static MySqlConnection ObtenerConexion()
       {
         
          MySqlConnection conectar = new MySqlConnection("server=127.0.0.1; database=stockcontrol; Uid=root; pwd=;");
            conectar.Open();
            return conectar;   
         
       }
    

*/

    



