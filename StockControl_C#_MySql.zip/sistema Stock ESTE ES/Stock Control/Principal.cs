﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace acceso
{
    public partial class Principal : Form
    {
        
        
        public Principal()
        {
            InitializeComponent();
        }

        
   

            private void Form1_Load(object sender, EventArgs e)
        {
            toolStripButton1.Enabled = true;

            Estado newMDIChild = new Estado();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {

        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void consultaDeStockToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void personalToolStripMenuItem_Click(object sender, EventArgs e)
        {
           


        }

        private void sistemaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void deToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ayudaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            Movimientos newMDIChild = new Movimientos();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();

            
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            {
                foreach (var form in Application.OpenForms.Cast<Form>().Where(f => f.IsMdiChild).ToArray()) // ToArray necessary to build a snapshot
                    form.Close();
                // Abrir Formulario Estado

                mant newMDIChild = new mant();
                newMDIChild.MdiParent = this;
                newMDIChild.Show(); 
            }










        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            Estado newMDIChild = new Estado();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();
        }

        private void ayudaToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void acercaDeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            about form1 = new about();

            form1.Show();
           
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Desea Salir? ");
            Application.Exit();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Estado newMDIChild = new Estado();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {

            MessageBox.Show("Desea Salir? ");

            Application.Exit();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            
        }

        private void herramientasToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void toolStripComboBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void Buscar_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton13_Click(object sender, EventArgs e)
        {

        }

        private void toolStripTextBox2_Click(object sender, EventArgs e)
        {

        }

        private void conexionToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void devoluciónToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void prestamoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Mantenimiento newMDIChild = new Mantenimiento();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();
        }

        private void toolStripButton5_Click_1(object sender, EventArgs e)
        {
            Mantenimiento newMDIChild = new Mantenimiento();
            newMDIChild.MdiParent = this;
            newMDIChild.Show();
        }

        private void prestamoDevolucionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            

        }

        private void toolStripSeparator1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton5_MouseHover(object sender, EventArgs e)
        {
            toolStripButton5.BackColor = Color.SteelBlue;
        }

        private void toolStripButton5_MouseLeave(object sender, EventArgs e)
        {
            toolStripButton5.BackColor = Color.LightGray;
        }

        

    }
}
